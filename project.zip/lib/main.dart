import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const gold = Color(0xFFE6B84A), bg = Colors.black, cardC = Color(0xFF1C1C1E);
const grn = Color(0xFF30D158), red = Color(0xFFFF453A), org = Color(0xFFFF9F0A);
const cur = '₹';
const cats = ['Food', 'Travel', 'Bills', 'Shopping', 'Health', 'Fun', 'Other'];
const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const bounce = BouncingScrollPhysics();
const pad = EdgeInsets.fromLTRB(20, 12, 20, 120);
const grad = LinearGradient(colors: [Color(0xFF3A2F0B), Color(0xFF141416)], begin: Alignment.topLeft, end: Alignment.bottomRight);

String fmt(double v) => cur + v.round().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');

class Tx {
  String type, cat, note;
  double amt;
  DateTime date;
  bool cash;
  Tx(this.type, this.amt, this.cat, this.note, this.date, this.cash);
  Map toJ() => {'t': type, 'a': amt, 'c': cat, 'n': note, 'd': date.millisecondsSinceEpoch, 'h': cash};
  factory Tx.fromJ(Map j) => Tx(j['t'], (j['a'] as num).toDouble(), j['c'], j['n'], DateTime.fromMillisecondsSinceEpoch(j['d']), j['h']);
}

class Ring extends CustomPainter {
  final double v;
  final Color c;
  Ring(this.v, this.c);
  @override
  void paint(Canvas cv, Size s) {
    final r = Rect.fromLTWH(6, 6, s.width - 12, s.height - 12);
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = 9..strokeCap = StrokeCap.round;
    cv.drawArc(r, 0, 6.2832, false, p..color = Colors.white12);
    cv.drawArc(r, -1.5708, 6.2832 * v, false, p..color = c);
  }
  @override
  bool shouldRepaint(Ring o) => o.v != v;
}

class Logo extends StatelessWidget {
  final double s;
  const Logo(this.s, {super.key});
  @override
  Widget build(BuildContext context) => Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(s * .24),
          gradient: const LinearGradient(colors: [Color(0xFFF5D76E), Color(0xFFB8860B)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: gold.withOpacity(.35), blurRadius: s / 3)]),
      child: Center(child: Text('V', style: TextStyle(fontSize: s * .6, fontWeight: FontWeight.w800, color: const Color(0xFF14151C)))));
}

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Vault',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
            scaffoldBackgroundColor: bg,
            colorScheme: const ColorScheme.dark(primary: gold),
            pageTransitionsTheme: PageTransitionsTheme(builders: {TargetPlatform.android: CupertinoPageTransitionsBuilder()})),
        home: const Splash(),
      );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashS();
}

class _SplashS extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => const Shell(),
          transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c)));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1200),
            curve: Curves.elasticOut,
            builder: (_, v, __) => Opacity(
              opacity: v.clamp(0.0, 1.0),
              child: Transform.scale(
                scale: v,
                child: const Column(mainAxisSize: MainAxisSize.min, children: [
                  Logo(100),
                  SizedBox(height: 18),
                  Text('Vault', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, letterSpacing: 2)),
                ]),
              ),
            ),
          ),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _S();
}

class _S extends State<Shell> {
  int tab = 0, payday = 1;
  List<Tx> txs = [];
  List goals = [], bills = [];
  Map budgets = {};

  DateTime get now => DateTime.now();
  DateTime get t0 => DateTime(now.year, now.month, now.day);
  DateTime get cStart {
    var d = DateTime(now.year, now.month, payday);
    if (d.isAfter(now)) d = DateTime(now.year, now.month - 1, payday);
    return d;
  }
  DateTime get cEnd => DateTime(cStart.year, cStart.month + 1, payday);
  int get daysLeft {
    final d = cEnd.difference(t0).inDays;
    return d < 1 ? 1 : d;
  }
  bool inCycle(Tx t) => !t.date.isBefore(cStart) && t.date.isBefore(cEnd);
  bool paid(Map b) => b['p'] == '${now.year}-${now.month}';
  DateTime due(Map b) {
    final d = b['d'] as int;
    return DateTime(now.year, now.month, d > 28 ? 28 : d);
  }
  String dueText(Map b) {
    if (paid(b)) return 'Paid ✓';
    final d = due(b).difference(t0).inDays;
    return d < 0 ? 'Overdue' : d == 0 ? 'Due today' : 'Due in $d days';
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  void fromMap(Map m) {
    txs = ((m['tx'] ?? []) as List).map((e) => Tx.fromJ(e)).toList();
    goals = List.from(m['g'] ?? []);
    bills = List.from(m['b'] ?? []);
    budgets = Map.from(m['bu'] ?? {});
    payday = (m['pd'] ?? 1) as int;
  }

  Map toMap() => {'tx': txs.map((e) => e.toJ()).toList(), 'g': goals, 'b': bills, 'bu': budgets, 'pd': payday};

  Future load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('db');
    if (s != null) fromMap(jsonDecode(s));
    setState(() {});
  }

  Future save() async {
    setState(() {});
    final p = await SharedPreferences.getInstance();
    await p.setString('db', jsonEncode(toMap()));
  }

  double s(bool Function(Tx) f) => txs.where(f).fold(0.0, (a, t) => a + t.amt);
  void snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<String?> ask(String t, {bool number = true}) {
    final c = TextEditingController();
    return showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
            title: Text(t),
            content: TextField(controller: c, autofocus: true, keyboardType: number ? TextInputType.number : TextInputType.text),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
              TextButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('OK')),
            ]));
  }

  Widget anim(int i, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + i * 80),
      curve: Curves.easeOut,
      builder: (_, v, ch) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 24 * (1 - v)), child: ch)),
      child: child);

  Widget box(Widget c, {Gradient? g}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: g == null ? cardC : null, gradient: g, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
      child: c);

  Widget title(String t) => Padding(padding: const EdgeInsets.only(top: 8, bottom: 16), child: Text(t, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)));
  Widget sec(String t, {Widget? trail}) => Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 10),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(t, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)), if (trail != null) trail]));

  Widget stat(String l, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(l, style: const TextStyle(color: Colors.white60)),
        Flexible(child: Text(v, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold))),
      ]));

  Widget ring(double v, Color c, double size, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: v.clamp(0.0, 1.0).toDouble()),
      duration: const Duration(milliseconds: 1000),
      curve: Curves.easeOutCubic,
      builder: (_, x, __) => SizedBox(width: size, height: size, child: CustomPaint(painter: Ring(x, c), child: Center(child: child))));

  Widget row(Tx t) {
    final inc = t.type == 'i';
    final col = inc ? grn : t.type == 'a' ? gold : red;
    return ListTile(
      leading: CircleAvatar(backgroundColor: col.withOpacity(0.15), child: Icon(inc ? Icons.south_west : t.type == 'a' ? Icons.atm : Icons.north_east, color: col)),
      title: Text(t.cat + (t.type == 'e' && t.cash ? ' · cash' : '')),
      subtitle: Text('${t.date.day} ${mon[t.date.month - 1]}${t.note.isEmpty ? '' : ' · ${t.note}'}'),
      trailing: Text((inc ? '+' : '-') + fmt(t.amt), style: TextStyle(fontWeight: FontWeight.bold, color: inc ? grn : Colors.white)),
    );
  }

  Widget home() {
    final cIn = s((t) => t.type == 'a');
    final cLeft = cIn - s((t) => t.type == 'e' && t.cash);
    final bank = s((t) => t.type == 'i') - s((t) => t.type == 'e' && !t.cash) - cIn;
    final inc = s((t) => t.type == 'i' && inCycle(t));
    final exp = s((t) => t.type == 'e' && inCycle(t));
    final dl = daysLeft;
    final total = cEnd.difference(cStart).inDays;
    final unpaid = bills.where((b) => !paid(b) && due(b).isBefore(cEnd)).fold(0.0, (x, b) => x + (b['a'] as num).toDouble());
    final free = bank + (cLeft < 0 ? 0.0 : cLeft) - unpaid;
    final perDay = free > 0 ? free / dl : 0.0;
    final up = bills.where((b) => !paid(b)).toList()..sort((x, y) => due(x).compareTo(due(y)));
    return ListView(physics: bounce, padding: pad, children: [
      const Row(children: [Logo(40), SizedBox(width: 12), Text('Vault', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800))]),
      const SizedBox(height: 18),
      anim(0, box(g: grad, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Total balance', style: TextStyle(color: Colors.white60)),
        TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: bank + cLeft),
            duration: const Duration(milliseconds: 1000),
            curve: Curves.easeOutCubic,
            builder: (_, v, __) => Text(fmt(v), style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w800, color: gold))),
        const SizedBox(height: 10),
        stat('Bank', fmt(bank)),
        stat('Cash in hand', fmt(cLeft)),
      ]))),
      anim(1, box(Row(children: [
        ring(1 - dl / total, gold, 96, Column(mainAxisSize: MainAxisSize.min, children: [Text('$dl', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)), const Text('days', style: TextStyle(fontSize: 11, color: Colors.white60))])),
        const SizedBox(width: 18),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Safe to spend / day', style: TextStyle(color: Colors.white60)),
          Text(fmt(perDay), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: grn)),
          Text('Next salary ${cEnd.day} ${mon[cEnd.month - 1]}', style: const TextStyle(color: Colors.white60)),
        ])),
      ]))),
      anim(2, Row(children: [
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Income', style: TextStyle(color: Colors.white60)), Text(fmt(inc), style: const TextStyle(fontSize: 20, color: grn, fontWeight: FontWeight.bold))]))),
        const SizedBox(width: 12),
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Spent', style: TextStyle(color: Colors.white60)), Text(fmt(exp), style: const TextStyle(fontSize: 20, color: red, fontWeight: FontWeight.bold))]))),
      ])),
      if (up.isNotEmpty) anim(3, box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Upcoming bills', style: TextStyle(fontWeight: FontWeight.w700)),
        ...up.take(2).map((b) => stat('${b['n']}  ${fmt((b['a'] as num).toDouble())}', dueText(b))),
      ]))),
      sec('Recent'),
      ...txs.take(4).toList().asMap().entries.map((e) => anim(e.key + 4, row(e.value))),
    ]);
  }

  Widget hist() => txs.isEmpty
      ? const Center(child: Text('No transactions yet'))
      : ListView.builder(
          physics: bounce,
          padding: pad,
          itemCount: txs.length + 1,
          itemBuilder: (_, i) {
            if (i == 0) return title('History');
            final t = txs[i - 1];
            return Dismissible(
                key: ObjectKey(t),
                background: Container(color: red.withOpacity(0.4)),
                onDismissed: (_) {
                  txs.remove(t);
                  save();
                },
                child: row(t));
          });

  Widget cash() {
    final at = txs.where((t) => t.type == 'a').toList()..sort((x, y) => x.date.compareTo(y.date));
    if (at.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('Add an ATM withdrawal (+ button) to see how long your cash lasts', textAlign: TextAlign.center)));
    final first = at.first.date;
    final d0 = now.difference(first).inDays + 1;
    final days = d0 < 1 ? 1 : d0;
    final spent = s((t) => t.type == 'e' && t.cash);
    final total = s((t) => t.type == 'a');
    final left = total - spent;
    final burn = spent / days;
    final dl = (burn > 0 && left > 0) ? left / burn : null;
    final gap = at.length > 1 ? at.last.date.difference(first).inDays / (at.length - 1) : null;
    final monthAtm = s((t) => t.type == 'a' && t.date.year == now.year && t.date.month == now.month);
    final end = dl == null ? now : now.add(Duration(days: dl.round()));
    return ListView(physics: bounce, padding: pad, children: [
      title('Cash'),
      anim(0, box(g: grad, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Cash will last', style: TextStyle(color: Colors.white60)),
        Text(dl == null ? (left <= 0 ? 'Cash finished' : 'Not enough data') : '~${dl.round()} days', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: gold)),
        if (dl != null) Text('till ${end.day} ${mon[end.month - 1]}', style: const TextStyle(color: Colors.white60)),
      ]))),
      anim(1, box(Column(children: [
        stat('Cash in hand', fmt(left < 0 ? 0.0 : left)),
        stat('Total withdrawn', fmt(total)),
        stat('Withdrawn this month', fmt(monthAtm)),
        stat('Withdrawals', '${at.length}'),
        stat('Daily cash spend', fmt(burn)),
        stat('Avg days between ATM visits', gap == null ? '—' : gap.toStringAsFixed(1)),
        stat('Last withdrawal', '${fmt(at.last.amt)} · ${now.difference(at.last.date).inDays} days ago'),
        stat('Suggested weekly cash', fmt(burn * 7)),
      ]))),
    ]);
  }

  Future setLimit(String c) async {
    final v = double.tryParse(await ask('Monthly limit · $c') ?? '');
    if (v == null) return;
    if (v == 0) {
      budgets.remove(c);
    } else {
      budgets[c] = v;
    }
    save();
  }

  Future addGoal() async {
    final n = await ask('Goal name', number: false);
    if (n == null || n.isEmpty) return;
    final t = double.tryParse(await ask('Target amount') ?? '');
    if (t == null || t <= 0) return;
    goals.add({'n': n, 't': t, 's': 0.0});
    save();
  }

  Future fund(Map g) async {
    final v = double.tryParse(await ask('Add to ${g['n']}') ?? '');
    if (v == null || v <= 0) return;
    g['s'] = (g['s'] as num) + v;
    txs.insert(0, Tx('e', v, 'Savings', '→ ${g['n']}', now, false));
    final done = (g['s'] as num) >= (g['t'] as num);
    await save();
    if (done && mounted) celebrate();
  }

  void celebrate() {
    showDialog(
        context: context,
        builder: (d) => Center(
            child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: const Duration(milliseconds: 800),
                curve: Curves.elasticOut,
                builder: (_, v, __) => Transform.scale(scale: v, child: const Text('🎉', style: TextStyle(fontSize: 90, decoration: TextDecoration.none))))));
    Future.delayed(const Duration(milliseconds: 1600), () {
      if (mounted) Navigator.of(context).pop();
    });
  }

  Widget plan() => ListView(physics: bounce, padding: pad, children: [
        title('Plan'),
        sec('Budgets'),
        box(Column(children: cats.map((c) {
          final sp = s((t) => t.type == 'e' && t.cat == c && inCycle(t));
          final l = budgets[c] == null ? null : (budgets[c] as num).toDouble();
          final r = (l == null || l == 0) ? 0.0 : sp / l;
          return GestureDetector(
              onTap: () => setLimit(c),
              behavior: HitTestBehavior.opaque,
              child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text(c),
                      Text(l == null ? '${fmt(sp)} · set limit' : '${fmt(sp)} / ${fmt(l)}', style: const TextStyle(color: Colors.white60)),
                    ]),
                    const SizedBox(height: 6),
                    TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0, end: r.clamp(0.0, 1.0).toDouble()),
                        duration: const Duration(milliseconds: 900),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 8, color: r < .8 ? grn : r < 1 ? org : red, backgroundColor: Colors.white10, borderRadius: BorderRadius.circular(8))),
                  ])));
        }).toList())),
        sec('Savings goals', trail: IconButton(onPressed: addGoal, icon: const Icon(Icons.add_circle_rounded, color: gold))),
        if (goals.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('No goals yet. Tap + to add one.', style: TextStyle(color: Colors.white60))),
        ...goals.map((g) {
          final t = (g['t'] as num).toDouble(), sv = (g['s'] as num).toDouble();
          final r = t == 0 ? 0.0 : sv / t;
          return Dismissible(
              key: ObjectKey(g),
              onDismissed: (_) {
                goals.remove(g);
                save();
              },
              child: box(Row(children: [
                ring(r, grn, 70, Text('${(r * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
                const SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${g['n']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                  Text('${fmt(sv)} of ${fmt(t)}', style: const TextStyle(color: Colors.white60)),
                ])),
                TextButton(onPressed: () => fund(g), child: const Text('Add')),
              ])));
        }),
      ]);

  Future addBill() async {
    final n = await ask('Bill name (Rent, EMI...)', number: false);
    if (n == null || n.isEmpty) return;
    final a = double.tryParse(await ask('Amount') ?? '');
    final d = int.tryParse(await ask('Due day of month (1-28)') ?? '');
    if (a == null || d == null || d < 1 || d > 31) return;
    bills.add({'n': n, 'a': a, 'd': d, 'p': ''});
    save();
  }

  void payBill(Map b) {
    txs.insert(0, Tx('e', (b['a'] as num).toDouble(), 'Bills', '${b['n']}', now, false));
    b['p'] = '${now.year}-${now.month}';
    save();
  }

  Widget more() => ListView(physics: bounce, padding: pad, children: [
        title('More'),
        box(ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Salary day'),
            subtitle: Text('Every month on day $payday'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final v = int.tryParse(await ask('Salary day (1-28)') ?? '');
              if (v != null && v >= 1 && v <= 28) {
                payday = v;
                save();
              }
            })),
        sec('Recurring bills', trail: IconButton(onPressed: addBill, icon: const Icon(Icons.add_circle_rounded, color: gold))),
        if (bills.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('No bills yet. Tap + to add rent, EMI, subscriptions.', style: TextStyle(color: Colors.white60))),
        ...bills.map((b) => Dismissible(
            key: ObjectKey(b),
            onDismissed: (_) {
              bills.remove(b);
              save();
            },
            child: box(Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${b['n']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                Text('${fmt((b['a'] as num).toDouble())} · day ${b['d']} · ${dueText(b)}', style: TextStyle(color: dueText(b) == 'Overdue' ? red : Colors.white60)),
              ])),
              if (!paid(b)) FilledButton(style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black), onPressed: () => payBill(b), child: const Text('Pay')),
            ])))),
        sec('Backup'),
        box(Column(children: [
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.copy_rounded, color: gold),
              title: const Text('Copy backup'),
              subtitle: const Text('Paste it in Notes or WhatsApp to keep safe'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: jsonEncode(toMap())));
                snack('Backup copied');
              }),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.restore_rounded, color: gold),
              title: const Text('Restore backup'),
              subtitle: const Text('Paste a copied backup'),
              onTap: () async {
                final r = await ask('Paste backup here', number: false);
                if (r == null || r.isEmpty) return;
                try {
                  fromMap(jsonDecode(r));
                  await save();
                  snack('Restored');
                } catch (_) {
                  snack('Invalid backup');
                }
              }),
        ])),
      ]);

  void add() {
    String type = 'e', cat = 'Food';
    bool cashPay = false;
    final a = TextEditingController(), n = TextEditingController();
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: cardC,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SegmentedButton<String>(
                      segments: const [ButtonSegment(value: 'e', label: Text('Expense')), ButtonSegment(value: 'i', label: Text('Income')), ButtonSegment(value: 'a', label: Text('ATM'))],
                      selected: {type},
                      onSelectionChanged: (v) => ss(() => type = v.first)),
                  const SizedBox(height: 12),
                  TextField(controller: a, keyboardType: TextInputType.number, autofocus: true, decoration: const InputDecoration(labelText: 'Amount', prefixText: cur)),
                  const SizedBox(height: 12),
                  if (type == 'e') Wrap(spacing: 8, children: cats.map((x) => ChoiceChip(label: Text(x), selected: cat == x, onSelected: (_) => ss(() => cat = x))).toList()),
                  if (type == 'e') SwitchListTile(title: const Text('Paid in cash (from ATM money)'), value: cashPay, onChanged: (v) => ss(() => cashPay = v)),
                  TextField(controller: n, decoration: const InputDecoration(labelText: 'Note (optional)')),
                  const SizedBox(height: 14),
                  FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(50)),
                      onPressed: () {
                        final v = double.tryParse(a.text);
                        if (v == null || v <= 0) return;
                        txs.insert(0, Tx(type, v, type == 'a' ? 'ATM' : type == 'i' ? 'Income' : cat, n.text, DateTime.now(), type == 'a' ? true : cashPay));
                        Navigator.pop(c);
                        HapticFeedback.mediumImpact();
                        save();
                      },
                      child: const Text('Save')),
                ])))));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [home(), hist(), cash(), plan(), more()];
    return Scaffold(
      extendBody: true,
      body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]))),
      floatingActionButton: Padding(
          padding: const EdgeInsets.only(bottom: 70),
          child: FloatingActionButton(backgroundColor: gold, foregroundColor: Colors.black, shape: const CircleBorder(), onPressed: add, child: const Icon(Icons.add))),
      bottomNavigationBar: ClipRect(
          child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
              child: NavigationBar(
                  backgroundColor: Colors.black.withOpacity(0.55),
                  indicatorColor: gold.withOpacity(0.22),
                  selectedIndex: tab,
                  onDestinationSelected: (i) {
                    HapticFeedback.selectionClick();
                    setState(() => tab = i);
                  },
                  destinations: const [
                    NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
                    NavigationDestination(icon: Icon(Icons.receipt_long_rounded), label: 'History'),
                    NavigationDestination(icon: Icon(Icons.atm_rounded), label: 'Cash'),
                    NavigationDestination(icon: Icon(Icons.donut_large_rounded), label: 'Plan'),
                    NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: 'More'),
                  ]))),
    );
  }
}
