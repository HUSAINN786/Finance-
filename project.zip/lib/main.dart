import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const gold = Color(0xFFD4AF37);
const bg = Color(0xFF0E0F14);
const cardC = Color(0xFF1A1C25);
const cur = '₹';
const cats = ['Food', 'Travel', 'Bills', 'Shopping', 'Health', 'Fun', 'Other'];
const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

String fmt(double v) => cur + v.round().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');

class Tx {
  String type, cat, note;
  double amt;
  DateTime date;
  bool cash;
  Tx(this.type, this.amt, this.cat, this.note, this.date, this.cash);
  Map toJ() => {'t': type, 'a': amt, 'c': cat, 'n': note, 'd': date.millisecondsSinceEpoch, 'h': cash};
  factory Tx.fromJ(Map j) => Tx(j['t'], (j['a'] as num).toDouble(), j['c'], j['n'], DateTime.fromMillisecondsSinceEpoch(j['d']), j['h']);
}

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Vault',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
            scaffoldBackgroundColor: bg,
            colorScheme: const ColorScheme.dark(primary: gold)),
        home: const Splash(),
      );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashS();
}

class _SplashS extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => const Shell(),
          transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c)));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1200),
            curve: Curves.elasticOut,
            builder: (_, v, __) => Opacity(
              opacity: v.clamp(0.0, 1.0),
              child: Transform.scale(
                scale: v,
                child: const Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.account_balance_wallet_rounded, size: 80, color: gold),
                  SizedBox(height: 12),
                  Text('VAULT', style: TextStyle(fontSize: 28, letterSpacing: 8, color: gold, fontWeight: FontWeight.w300)),
                ]),
              ),
            ),
          ),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _S();
}

class _S extends State<Shell> {
  int tab = 0;
  List<Tx> txs = [];
  final now = DateTime.now();

  @override
  void initState() {
    super.initState();
    load();
  }

  Future load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('tx');
    if (s != null) txs = (jsonDecode(s) as List).map((e) => Tx.fromJ(e)).toList();
    setState(() {});
  }

  Future save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tx', jsonEncode(txs.map((e) => e.toJ()).toList()));
    setState(() {});
  }

  double s(bool Function(Tx) f) => txs.where(f).fold(0.0, (a, t) => a + t.amt);
  bool thisMonth(Tx t) => t.date.year == now.year && t.date.month == now.month;

  Widget anim(int i, Widget child) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + i * 80),
      curve: Curves.easeOut,
      builder: (_, v, ch) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 24 * (1 - v)), child: ch)),
      child: child);

  Widget box(Widget c, {Gradient? g}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: g == null ? cardC : null, gradient: g, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
      child: c);

  Widget stat(String l, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(l, style: const TextStyle(color: Colors.white60)),
        Text(v, style: const TextStyle(fontWeight: FontWeight.bold)),
      ]));

  Widget row(Tx t) {
    final inc = t.type == 'i';
    return ListTile(
      leading: CircleAvatar(
          backgroundColor: (inc ? Colors.greenAccent : t.type == 'a' ? gold : Colors.redAccent).withOpacity(0.15),
          child: Icon(inc ? Icons.south_west : t.type == 'a' ? Icons.atm : Icons.north_east, color: inc ? Colors.greenAccent : t.type == 'a' ? gold : Colors.redAccent)),
      title: Text(t.cat + (t.type == 'e' && t.cash ? ' · cash' : '')),
      subtitle: Text('${t.date.day} ${mon[t.date.month - 1]}${t.note.isEmpty ? '' : ' · ${t.note}'}'),
      trailing: Text((inc ? '+' : '-') + fmt(t.amt), style: TextStyle(fontWeight: FontWeight.bold, color: inc ? Colors.greenAccent : Colors.white)),
    );
  }

  Widget home() {
    final cashIn = s((t) => t.type == 'a');
    final cashLeft = cashIn - s((t) => t.type == 'e' && t.cash);
    final bank = s((t) => t.type == 'i') - s((t) => t.type == 'e' && !t.cash) - cashIn;
    final inc = s((t) => t.type == 'i' && thisMonth(t));
    final exp = s((t) => t.type == 'e' && thisMonth(t));
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Total balance', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 10),
      anim(0, box(g: const LinearGradient(colors: [Color(0xFF3A2F0B), Color(0xFF14151C)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: bank + cashLeft),
                duration: const Duration(milliseconds: 1000),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Text(fmt(v), style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold, color: gold))),
            const SizedBox(height: 12),
            stat('Bank', fmt(bank)),
            stat('Cash in hand', fmt(cashLeft)),
          ]))),
      anim(1, Row(children: [
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Income', style: TextStyle(color: Colors.white60)), Text(fmt(inc), style: const TextStyle(fontSize: 20, color: Colors.greenAccent, fontWeight: FontWeight.bold))]))),
        const SizedBox(width: 12),
        Expanded(child: box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Expenses', style: TextStyle(color: Colors.white60)), Text(fmt(exp), style: const TextStyle(fontSize: 20, color: Colors.redAccent, fontWeight: FontWeight.bold))]))),
      ])),
      const Text('Recent', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ...txs.take(5).toList().asMap().entries.map((e) => anim(e.key + 2, row(e.value))),
    ]);
  }

  Widget hist() => txs.isEmpty
      ? const Center(child: Text('No transactions yet'))
      : ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: txs.length,
          itemBuilder: (_, i) {
            final t = txs[i];
            return anim(i < 8 ? i : 0, Dismissible(
                key: ObjectKey(t),
                background: Container(color: Colors.red.withOpacity(0.4)),
                onDismissed: (_) {
                  txs.remove(t);
                  save();
                },
                child: row(t)));
          });

  Widget stats() {
    final m = <String, double>{};
    for (final t in txs.where((t) => t.type == 'e' && thisMonth(t))) {
      m[t.cat] = (m[t.cat] ?? 0) + t.amt;
    }
    final top = m.values.fold(1.0, (a, b) => b > a ? b : a);
    final months = [for (var k = 5; k >= 0; k--) DateTime(now.year, now.month - k)];
    double mt(DateTime d, String ty) => s((t) => t.type == ty && t.date.year == d.year && t.date.month == d.month);
    final mx = months.fold(1.0, (a, d) => [a, mt(d, 'i'), mt(d, 'e')].reduce((x, y) => x > y ? x : y));
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Spending this month', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      box(Column(children: m.isEmpty ? [const Text('No expenses yet')] : m.entries.map((e) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(e.key), Text(fmt(e.value))]),
            const SizedBox(height: 6),
            TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: e.value / top),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 10, color: gold, backgroundColor: Colors.white10, borderRadius: BorderRadius.circular(8))),
          ]))).toList())),
      const Text('Last 6 months', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      box(SizedBox(height: 170, child: Row(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.spaceAround, children: months.map((d) => Column(mainAxisAlignment: MainAxisAlignment.end, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: 120 * mt(d, 'i') / mx), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => Container(width: 10, height: v, decoration: BoxDecoration(color: Colors.greenAccent, borderRadius: BorderRadius.circular(4)))),
          const SizedBox(width: 3),
          TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: 120 * mt(d, 'e') / mx), duration: const Duration(milliseconds: 900), curve: Curves.easeOutCubic, builder: (_, v, __) => Container(width: 10, height: v, decoration: BoxDecoration(color: Colors.redAccent, borderRadius: BorderRadius.circular(4)))),
        ]),
        const SizedBox(height: 6),
        Text(mon[d.month - 1], style: const TextStyle(fontSize: 11, color: Colors.white60)),
      ])).toList()))),
    ]);
  }

  Widget cash() {
    final at = txs.where((t) => t.type == 'a').toList()..sort((x, y) => x.date.compareTo(y.date));
    if (at.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('Add an ATM withdrawal (+ button) to see how long your cash lasts', textAlign: TextAlign.center)));
    final first = at.first.date;
    final d0 = now.difference(first).inDays + 1;
    final days = d0 < 1 ? 1 : d0;
    final spent = s((t) => t.type == 'e' && t.cash);
    final total = s((t) => t.type == 'a');
    final left = total - spent;
    final burn = spent / days;
    final dl = (burn > 0 && left > 0) ? left / burn : null;
    final gap = at.length > 1 ? at.last.date.difference(first).inDays / (at.length - 1) : null;
    final monthAtm = s((t) => t.type == 'a' && thisMonth(t));
    return ListView(padding: const EdgeInsets.all(20), children: [
      anim(0, box(g: const LinearGradient(colors: [Color(0xFF3A2F0B), Color(0xFF14151C)]),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Cash will last', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 6),
            Text(dl == null ? (left <= 0 ? 'Cash finished' : 'Not enough data') : '~${dl.round()} days', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: gold)),
            if (dl != null) Text('till ${now.add(Duration(days: dl.round())).day} ${mon[now.add(Duration(days: dl.round())).month - 1]}', style: const TextStyle(color: Colors.white60)),
          ]))),
      anim(1, box(Column(children: [
        stat('Cash in hand', fmt(left < 0 ? 0 : left)),
        stat('Total withdrawn', fmt(total)),
        stat('Withdrawn this month', fmt(monthAtm)),
        stat('Withdrawals', '${at.length}'),
        stat('Daily cash spend', fmt(burn)),
        stat('Avg days between ATM visits', gap == null ? '—' : gap.toStringAsFixed(1)),
        stat('Last withdrawal', '${fmt(at.last.amt)} · ${now.difference(at.last.date).inDays} days ago'),
        stat('Suggested weekly cash', fmt(burn * 7)),
      ]))),
    ]);
  }

  void add() {
    String type = 'e', cat = 'Food';
    bool cashPay = false;
    final a = TextEditingController(), n = TextEditingController();
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: cardC,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (c) => StatefulBuilder(
            builder: (c, ss) => Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SegmentedButton<String>(
                      segments: const [ButtonSegment(value: 'e', label: Text('Expense')), ButtonSegment(value: 'i', label: Text('Income')), ButtonSegment(value: 'a', label: Text('ATM'))],
                      selected: {type},
                      onSelectionChanged: (v) => ss(() => type = v.first)),
                  const SizedBox(height: 12),
                  TextField(controller: a, keyboardType: TextInputType.number, autofocus: true, decoration: const InputDecoration(labelText: 'Amount', prefixText: cur)),
                  const SizedBox(height: 12),
                  if (type == 'e') Wrap(spacing: 8, children: cats.map((x) => ChoiceChip(label: Text(x), selected: cat == x, onSelected: (_) => ss(() => cat = x))).toList()),
                  if (type == 'e') SwitchListTile(title: const Text('Paid in cash (from ATM money)'), value: cashPay, onChanged: (v) => ss(() => cashPay = v)),
                  TextField(controller: n, decoration: const InputDecoration(labelText: 'Note (optional)')),
                  const SizedBox(height: 14),
                  FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(50)),
                      onPressed: () {
                        final v = double.tryParse(a.text);
                        if (v == null || v <= 0) return;
                        txs.insert(0, Tx(type, v, type == 'a' ? 'ATM' : type == 'i' ? 'Income' : cat, n.text, DateTime.now(), type == 'a' ? true : cashPay));
                        Navigator.pop(c);
                        save();
                      },
                      child: const Text('Save')),
                ])))));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [home(), hist(), stats(), cash()];
    return Scaffold(
      body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]))),
      floatingActionButton: FloatingActionButton(backgroundColor: gold, foregroundColor: Colors.black, onPressed: add, child: const Icon(Icons.add)),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.receipt_long_rounded), label: 'History'),
        NavigationDestination(icon: Icon(Icons.pie_chart_rounded), label: 'Stats'),
        NavigationDestination(icon: Icon(Icons.atm_rounded), label: 'Cash'),
      ]),
    );
  }
}
