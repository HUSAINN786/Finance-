# Vault

A personal finance manager for salaried people, built with Flutter.

## Features
- Setup flow (name, salary, pay day, opening bank + cash) and a Profile tab
- Ivory & gold light theme, with dark mode (Light / Dark / System)
- Salary planner (50/30/20), safe-to-spend per day, smart insights
- Multiple accounts (bank, cash, UPI), transfers, credit-card tracker
- EMI / loan tracker, recurring bills, udhaar (who owes whom), net worth, savings goals, budgets
- Add screen with big keypad, category icons, any date, notes and tags
- History with search, filters, tags, swipe to edit / delete (with undo)
- Reports: donut, 6-month trend, top spends, weekday heatmap
- Animations: count-up numbers, gold shimmer, self-drawing charts, coin drop, confetti, animated tab bar, haptics
- Notifications: bills/EMI/card dues, budget 80%, salary day, low cash, daily summary

## Build
Push to GitHub; the workflow in `.github/workflows/build.yml` generates the Android project,
patches it for notifications and builds `app-release.apk` (download from the Actions run → Artifacts).

Local build:
```
flutter create --platforms=android --org com.sainify --project-name vault .   # restore lib/ + pubspec.yaml if overwritten
cp -r res/mipmap-* android/app/src/main/res/
python3 tools/patch_android.py
flutter build apk --release
```
