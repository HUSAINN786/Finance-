import 'package:flutter/material.dart';
import 'add_sheet.dart';
import 'core.dart';
import 'ui.dart';

class HomePage extends StatelessWidget {
  final void Function(int) goTab;
  const HomePage({super.key, required this.goTab});

  String greet() {
    final h = DateTime.now().hour;
    return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  }

  @override
  Widget build(BuildContext context) => Live((context) {
        final p = Pal.of(context);
        final s = store;
        final dl = s.daysLeft, total = s.totalDays;
        final base = s.salary > 0 ? s.salary : s.cycIncome;
        final insights = s.insights();
        final dues = s.dues().take(3).toList();
        final dark = Theme.of(context).brightness == Brightness.dark;
        var i = 0;
        return ListView(physics: bounce, padding: pagePad, children: [
          Pop(
              i++,
              Row(children: [
                GestureDetector(
                    onTap: () => goTab(4),
                    child: Container(width: 46, height: 46, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: heroGrad), child: Center(child: Text(s.name.isEmpty ? 'V' : s.name[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20))))),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(greet(), style: TextStyle(color: p.sub, fontSize: 13)), Text(s.name.isEmpty ? 'Welcome' : s.name, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800))])),
                IconButton(onPressed: () => s.setMode(dark ? 'light' : 'dark'), icon: Icon(dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded, color: p.accent)),
              ])),
          const SizedBox(height: 16),
          Pop(
              i++,
              AppCard(
                  gradient: heroGrad,
                  padding: const EdgeInsets.all(22),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Total balance', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Shine(child: Count(s.liquid, style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800, color: Colors.white))),
                    const SizedBox(height: 14),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      for (final a in s.accs.where((a) => a.kind != 'card'))
                        Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(.14), borderRadius: BorderRadius.circular(14)),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(accIcon(a.kind), size: 16, color: Colors.white), const SizedBox(width: 6), Text('${a.name}  ${fmt(s.bal(a))}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12.5))])),
                    ]),
                  ]))),
          if (s.txs.isEmpty)
            Pop(
                i++,
                AppCard(
                    child: Column(children: [
                  const SizedBox(height: 4),
                  Text('Welcome, ${s.name.isEmpty ? 'friend' : s.name}! 👋', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text('Your vault is ready. Add your first transaction to unlock insights, your 50/30/20 plan and reports.', textAlign: TextAlign.center, style: TextStyle(color: p.sub, height: 1.4)),
                  const SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
                    FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent), onPressed: () => openAdd(context), icon: const Icon(Icons.add_rounded), label: const Text('Add expense')),
                    if (s.salary > 0) OutlinedButton.icon(onPressed: () => openAdd(context, type: 'i', amount: s.salary), icon: const Icon(Icons.payments_rounded), label: const Text('Log salary')),
                  ]),
                ])))
          else ...[
            if (s.needSalary)
              Pop(
                  i++,
                  AppCard(
                      child: Row(children: [
                    Container(width: 44, height: 44, decoration: BoxDecoration(color: grn.withOpacity(.14), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.payments_rounded, color: grn)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Salary credited?', style: TextStyle(fontWeight: FontWeight.w800)), Text('Log ${fmt(s.salary)} for this month', style: TextStyle(color: p.sub, fontSize: 13))])),
                    TextButton(onPressed: s.snoozeSalary, child: Text('Later', style: TextStyle(color: p.sub))),
                    FilledButton(style: FilledButton.styleFrom(backgroundColor: grn, foregroundColor: Colors.white), onPressed: () => openAdd(context, type: 'i', amount: s.salary), child: const Text('Log')),
                  ]))),
            Pop(
                i++,
                AppCard(
                    child: Row(children: [
                  RingW(1 - dl / (total < 1 ? 1 : total), p.accent, 98, Column(mainAxisSize: MainAxisSize.min, children: [Text('$dl', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)), Text('days left', style: TextStyle(fontSize: 11, color: p.sub))])),
                  const SizedBox(width: 18),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Safe to spend / day', style: TextStyle(color: p.sub)),
                    Count(s.safePerDay, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: grn)),
                    Text('Next salary ${s.cEnd.day} ${mon[s.cEnd.month - 1]}', style: TextStyle(color: p.sub)),
                  ])),
                ]))),
            Pop(
                i++,
                Row(children: [
                  Expanded(child: AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Income', style: TextStyle(color: p.sub)), const SizedBox(height: 4), Count(s.cycIncome, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: grn))]))),
                  const SizedBox(width: 12),
                  Expanded(child: AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Spent', style: TextStyle(color: p.sub)), const SizedBox(height: 4), Count(s.cycSpent, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: red))]))),
                ])),
          ],
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [const Icon(Icons.pie_chart_rounded, size: 20, color: blue), const SizedBox(width: 8), const Text('Salary planner · 50/30/20', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))]),
                const SizedBox(height: 14),
                if (base <= 0)
                  Text('Set your monthly salary in Profile to see your plan.', style: TextStyle(color: p.sub))
                else ...[
                  _plan(p, 'Needs', .5, base, s.spentGrp('n'), blue, true),
                  _plan(p, 'Wants', .3, base, s.spentGrp('w'), violet, true),
                  _plan(p, 'Savings', .2, base, s.spentGrp('s'), grn, false),
                ],
              ]))),
          if (insights.isNotEmpty)
            Pop(
                i++,
                AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Smart insights', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: 10),
                  for (final n in insights)
                    Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Container(width: 34, height: 34, decoration: BoxDecoration(color: n.color.withOpacity(.14), borderRadius: BorderRadius.circular(11)), child: Icon(n.icon, size: 19, color: n.color)),
                          const SizedBox(width: 12),
                          Expanded(child: Padding(padding: const EdgeInsets.only(top: 7), child: Text(n.text, style: const TextStyle(height: 1.3)))),
                        ])),
                ]))),
          if (dues.isNotEmpty)
            Pop(
                i++,
                AppCard(
                    onTap: () => goTab(3),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Coming up', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 8),
                      for (final d in dues)
                        Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(children: [
                              Icon(d.icon, color: d.color, size: 22),
                              const SizedBox(width: 12),
                              Expanded(child: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
                              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(fmt(d.amt), style: const TextStyle(fontWeight: FontWeight.w800)), Text(s.whenText(d.date), style: TextStyle(fontSize: 12, color: d.date.isBefore(s.today) ? red : p.sub))]),
                            ])),
                    ]))),
          if (s.txs.isNotEmpty) ...[
            Pop(i++, const Sec('Recent')),
            for (final t in s.txs.take(4)) Pop(i++, TxTile(t, onTap: () => openAdd(context, edit: t))),
          ],
        ]);
      });

  Widget _plan(Pal p, String label, double pct, double base, double spent, Color c, bool limit) {
    final target = base * pct;
    final r = target <= 0 ? 0.0 : spent / target;
    final over = limit && r > 1;
    return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('$label · ${(pct * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('${fmt(spent)} / ${fmt(target)}', style: TextStyle(color: over ? red : p.sub, fontSize: 13, fontWeight: over ? FontWeight.w700 : FontWeight.w500)),
          ]),
          const SizedBox(height: 6),
          Bar(r, over ? red : c, h: 9),
        ]));
  }
}
