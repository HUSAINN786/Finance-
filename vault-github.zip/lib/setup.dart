import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'ui.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupS();
}

class _SetupS extends State<SetupScreen> {
  final pc = PageController();
  int page = 0;
  bool remind = true, busy = false;
  late final TextEditingController nameC = TextEditingController(text: store.name);
  late final TextEditingController salC = TextEditingController(text: store.salary > 0 ? trimNum(store.salary) : '');
  late final TextEditingController bankC = TextEditingController();
  late final TextEditingController cashC = TextEditingController();
  int payday = store.payday;
  String? err;

  @override
  void dispose() {
    pc.dispose();
    nameC.dispose();
    salC.dispose();
    bankC.dispose();
    cashC.dispose();
    super.dispose();
  }

  Future<void> next() async {
    HapticFeedback.selectionClick();
    FocusScope.of(context).unfocus();
    if (page == 0 && nameC.text.trim().isEmpty) {
      setState(() => err = 'Please tell me your name');
      return;
    }
    setState(() => err = null);
    if (page < 3) {
      pc.nextPage(duration: const Duration(milliseconds: 420), curve: Curves.easeOutCubic);
      return;
    }
    setState(() => busy = true);
    await store.finishSetup(nameC.text.trim(), pnum(salC.text) ?? 0, payday, pnum(bankC.text) ?? 0, pnum(cashC.text) ?? 0, remind);
    HapticFeedback.mediumImpact();
  }

  Widget field(Pal p, TextEditingController c, String label, {bool num = true, String? prefix, IconData? icon}) => TextField(
      controller: c,
      keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.name,
      textCapitalization: num ? TextCapitalization.none : TextCapitalization.words,
      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
      decoration: InputDecoration(
          labelText: label,
          prefixText: prefix,
          prefixIcon: icon == null ? null : Icon(icon, color: p.accent),
          filled: true,
          fillColor: p.card,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.line)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.accent, width: 2))));

  Widget step(Pal p, IconData icon, String title, String sub, List<Widget> body) => SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(26, 20, 26, 20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 64, height: 64, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: heroGrad), child: Icon(icon, color: Colors.white, size: 32)),
        const SizedBox(height: 22),
        Text(title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, height: 1.15)),
        const SizedBox(height: 8),
        Text(sub, style: TextStyle(color: p.sub, fontSize: 15, height: 1.4)),
        const SizedBox(height: 26),
        ...body,
      ]));

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Scaffold(
        body: SafeArea(
            child: Column(children: [
      Padding(
          padding: const EdgeInsets.fromLTRB(26, 14, 26, 0),
          child: Row(children: [
            const Logo(34),
            const SizedBox(width: 10),
            const Text('Vault', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const Spacer(),
            for (var i = 0; i < 4; i++)
              AnimatedContainer(duration: const Duration(milliseconds: 300), margin: const EdgeInsets.only(left: 6), width: i == page ? 24 : 8, height: 8, decoration: BoxDecoration(color: i <= page ? p.accent : p.line, borderRadius: BorderRadius.circular(8))),
          ])),
      Expanded(
          child: PageView(controller: pc, physics: const NeverScrollableScrollPhysics(), onPageChanged: (i) => setState(() => page = i), children: [
        step(p, Icons.waving_hand_rounded, 'Welcome!\nWhat should we call you?', 'Vault keeps your salary, spending and savings in one calm place.', [
          field(p, nameC, 'Your name', num: false, icon: Icons.person_rounded),
          if (err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(err!, style: const TextStyle(color: red))),
        ]),
        step(p, Icons.payments_rounded, 'Your salary', 'Used for your 50/30/20 plan and your monthly cycle. You can change it anytime.', [
          field(p, salC, 'Monthly salary (in hand)', prefix: cur, icon: Icons.account_balance_wallet_rounded),
          const SizedBox(height: 20),
          Text('Salary day of the month', style: TextStyle(color: p.sub, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [for (var d = 1; d <= 28; d++) SizedBox(width: 42, child: Pill('$d', payday == d, () => setState(() => payday = d)))]),
        ]),
        step(p, Icons.account_balance_rounded, 'What do you have right now?', 'Opening balances so your totals start correct. Leave 0 if unsure.', [
          field(p, bankC, 'Bank balance', prefix: cur, icon: Icons.account_balance_rounded),
          const SizedBox(height: 14),
          field(p, cashC, 'Cash in hand', prefix: cur, icon: Icons.payments_rounded),
          const SizedBox(height: 10),
          Text('You can add UPI wallets and credit cards later from the Money tab.', style: TextStyle(color: p.sub, fontSize: 13)),
        ]),
        step(p, Icons.notifications_active_rounded, 'Stay on track', 'Gentle reminders for bills, EMIs, salary day, budgets and low cash.', [
          AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: p.accent,
                  title: const Text('Smart reminders', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: const Text('You can fine-tune each one in Profile'),
                  value: remind,
                  onChanged: (v) => setState(() => remind = v))),
        ]),
      ])),
      Padding(
          padding: const EdgeInsets.fromLTRB(26, 8, 26, 22),
          child: Row(children: [
            if (page > 0)
              TextButton(onPressed: () => pc.previousPage(duration: const Duration(milliseconds: 350), curve: Curves.easeOut), child: Text('Back', style: TextStyle(color: p.sub))),
            const Spacer(),
            FilledButton(
                style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent, padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))),
                onPressed: busy ? null : next,
                child: Text(page == 3 ? 'Start using Vault' : 'Continue', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          ])),
    ])));
  }
}
