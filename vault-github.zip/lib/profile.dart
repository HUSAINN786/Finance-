import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'notif.dart';
import 'ui.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  Future<void> editProfile(BuildContext context) async {
    final s = store;
    final r = await formDialog(context, 'Edit profile', [F('Name', init: s.name), F('Monthly salary', num: true, init: s.salary > 0 ? trimNum(s.salary) : ''), F('Salary day (1-28)', num: true, init: '${s.payday}')]);
    if (r == null) return;
    if (r[0].isNotEmpty) s.name = r[0];
    s.salary = pnum(r[1]) ?? s.salary;
    final d = int.tryParse(r[2]);
    if (d != null && d >= 1 && d <= 28) s.payday = d;
    s.save();
  }

  Widget row(BuildContext context, Pal p, IconData ic, String title, String sub, {Widget? trail, VoidCallback? onTap}) => InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: p.accent.withOpacity(.14), borderRadius: BorderRadius.circular(13)), child: Icon(ic, color: p.accent, size: 21)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), Text(sub, style: TextStyle(color: p.sub, fontSize: 12.5))])),
            if (trail != null) trail,
          ])));

  Widget nRow(BuildContext context, Pal p, String key, IconData ic, String title, String sub, {bool time = false, bool cash = false}) {
    final s = store;
    final m = s.notif[key] as Map;
    final on = m['on'] == true;
    final tod = time ? TimeOfDay(hour: (m['h'] as num).toInt(), minute: (m['m'] as num).toInt()) : null;
    return row(context, p, ic, title, sub,
        trail: Row(mainAxisSize: MainAxisSize.min, children: [
          if (on && time)
            GestureDetector(
                onTap: () async {
                  final t = await showTimePicker(context: context, initialTime: tod!);
                  if (t != null) s.setNotifTime(key, t.hour, t.minute);
                },
                child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: p.chip, borderRadius: BorderRadius.circular(10)), child: Text(tod!.format(context), style: TextStyle(color: p.accent, fontWeight: FontWeight.w800, fontSize: 12.5)))),
          if (on && cash)
            GestureDetector(
                onTap: () async {
                  final r = await formDialog(context, 'Low cash limit', [F('Warn me below', num: true, init: trimNum((m['v'] as num).toDouble()))]);
                  final v = r == null ? null : pnum(r[0]);
                  if (v != null) s.setLowCash(v);
                },
                child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: p.chip, borderRadius: BorderRadius.circular(10)), child: Text('< ${fmt((m['v'] as num).toDouble())}', style: TextStyle(color: p.accent, fontWeight: FontWeight.w800, fontSize: 12.5)))),
          Switch(
              value: on,
              activeColor: p.accent,
              onChanged: (v) async {
                HapticFeedback.selectionClick();
                final ok = await s.toggleNotif(key, v);
                if (!ok && context.mounted) snack(context, 'Notification permission was denied. Enable it in system settings.');
              }),
        ]));
  }

  @override
  Widget build(BuildContext context) => Live((context) {
        final p = Pal.of(context);
        final s = store;
        var i = 0;
        return ListView(physics: bounce, padding: pagePad, children: [
          const PageTitle('Profile'),
          Pop(
              i++,
              AppCard(
                  gradient: heroGrad,
                  padding: const EdgeInsets.all(20),
                  onTap: () => editProfile(context),
                  child: Row(children: [
                    Container(width: 64, height: 64, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.18)), child: Center(child: Text(s.name.isEmpty ? 'V' : s.name[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)))),
                    const SizedBox(width: 16),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(s.name.isEmpty ? 'Your name' : s.name, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                      Text('Salary ${fmt(s.salary)} · day ${s.payday}', style: const TextStyle(color: Colors.white70)),
                    ])),
                    const Icon(Icons.edit_rounded, color: Colors.white70),
                  ]))),
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Appearance', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 12),
                Row(children: [
                  for (final e in const [['light', 'Light', Icons.light_mode_rounded], ['dark', 'Dark', Icons.dark_mode_rounded], ['system', 'System', Icons.phone_android_rounded]])
                    Padding(padding: const EdgeInsets.only(right: 8), child: Pill(e[1] as String, s.themeMode == e[0], () => s.setMode(e[0] as String), icon: e[2] as IconData)),
                ]),
              ]))),
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 4),
                nRow(context, p, 'bill', Icons.receipt_long_rounded, 'Bills, EMI & card dues', 'Day before and on the due date', time: true),
                nRow(context, p, 'budget', Icons.speed_rounded, 'Budget warning', 'When a category reaches 80%'),
                nRow(context, p, 'salary', Icons.payments_rounded, 'Salary day', 'Monthly reminder to log salary', time: true),
                nRow(context, p, 'cash', Icons.atm_rounded, 'Low cash', 'When cash in hand runs low', cash: true),
                nRow(context, p, 'daily', Icons.today_rounded, 'Daily summary', 'Evening nudge to review spending', time: true),
                const SizedBox(height: 4),
                TextButton.icon(
                    onPressed: () async {
                      final ok = await Notif.askPermission();
                      await Notif.show(99, 'Vault', ok ? 'Reminders are working 🎉' : 'Please allow notifications in system settings.');
                    },
                    icon: Icon(Icons.notifications_active_rounded, color: p.accent),
                    label: Text('Send a test notification', style: TextStyle(color: p.accent, fontWeight: FontWeight.w700))),
              ]))),
          Pop(
              i++,
              AppCard(
                  child: Column(children: [
                row(context, p, Icons.copy_rounded, 'Copy backup', 'Paste it in Notes or WhatsApp to keep it safe', onTap: () {
                  Clipboard.setData(ClipboardData(text: jsonEncode(s.toMap())));
                  snack(context, 'Backup copied');
                }),
                row(context, p, Icons.restore_rounded, 'Restore backup', 'Paste a copied backup', onTap: () async {
                  final r = await formDialog(context, 'Restore backup', [const F('Paste backup here')], ok: 'Restore');
                  if (r == null || r[0].isEmpty) return;
                  try {
                    s.fromMap(jsonDecode(r[0]) as Map);
                    await s.save();
                    if (context.mounted) snack(context, 'Restored');
                  } catch (_) {
                    if (context.mounted) snack(context, 'Invalid backup');
                  }
                }),
                row(context, p, Icons.delete_forever_rounded, 'Reset everything', 'Erase all data and start over', onTap: () async {
                  final ok = await confirmDialog(context, 'Reset Vault?', 'All transactions, accounts and goals will be erased from this phone.', ok: 'Erase');
                  if (ok) await s.resetAll();
                }),
              ]))),
          Center(child: Text('Vault v3.0', style: TextStyle(color: p.sub, fontSize: 12))),
        ]);
      });
}
