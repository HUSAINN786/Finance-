import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'add_sheet.dart';
import 'core.dart';
import 'ui.dart';

const _secs = ['Accounts', 'Cards', 'Bills', 'EMI', 'Udhaar', 'Net worth', 'Goals', 'Budgets'];

class MoneyPage extends StatefulWidget {
  const MoneyPage({super.key});
  @override
  State<MoneyPage> createState() => _MoneyS();
}

class _MoneyS extends State<MoneyPage> {
  int sec = 0;

  Widget addBtn(Pal p, String label, VoidCallback f, {IconData icon = Icons.add_rounded}) => Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: OutlinedButton.icon(
          style: OutlinedButton.styleFrom(foregroundColor: p.accent, side: BorderSide(color: p.accent.withOpacity(.5)), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
          onPressed: f,
          icon: Icon(icon),
          label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))));

  Widget hint(Pal p, String t) => Padding(padding: const EdgeInsets.all(18), child: Center(child: Text(t, textAlign: TextAlign.center, style: TextStyle(color: p.sub, height: 1.4))));

  Widget swipe(Object key, Widget child, Future<void> Function() onDelete) => Dismissible(
      key: ValueKey(key),
      direction: DismissDirection.endToStart,
      background: Container(margin: const EdgeInsets.only(bottom: 14), padding: const EdgeInsets.only(right: 22), alignment: Alignment.centerRight, decoration: BoxDecoration(color: red.withOpacity(.9), borderRadius: BorderRadius.circular(22)), child: const Icon(Icons.delete_rounded, color: Colors.white)),
      confirmDismiss: (_) => confirmDialog(context, 'Delete?', 'This cannot be undone.'),
      onDismissed: (_) {
        HapticFeedback.mediumImpact();
        onDelete();
      },
      child: child);

  // ---------------- Accounts ----------------
  List<Widget> accounts(Pal p) {
    final s = store;
    final list = s.accs.where((a) => a.kind != 'card').toList();
    return [
      AppCard(
          gradient: heroGrad,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Available money', style: TextStyle(color: Colors.white70)),
            Shine(child: Count(s.liquid, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Colors.white))),
          ])),
      Row(children: [
        Expanded(child: addBtn(p, 'Add account', addAccount)),
        const SizedBox(width: 10),
        Expanded(child: addBtn(p, 'Transfer', () => openAdd(context, type: 't'), icon: Icons.swap_horiz_rounded)),
      ]),
      for (final a in list)
        AppCard(
            child: Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(color: p.accent.withOpacity(.14), borderRadius: BorderRadius.circular(15)), child: Icon(accIcon(a.kind), color: p.accent)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(a.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), Text(a.kind.toUpperCase(), style: TextStyle(color: p.sub, fontSize: 11.5, letterSpacing: 1))])),
          Count(s.bal(a), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: s.bal(a) < 0 ? red : p.text)),
          PopupMenuButton<String>(
              color: p.card,
              icon: Icon(Icons.more_vert_rounded, color: p.sub),
              onSelected: (v) async {
                if (v == 'edit') {
                  final r = await formDialog(context, 'Edit account', [F('Name', init: a.name), F('Current balance', num: true, init: trimNum(s.bal(a)))]);
                  if (r != null && r[0].isNotEmpty) {
                    a.name = r[0];
                    final nb = pnum(r[1]);
                    if (nb != null) {
                      a.open = 0;
                      a.open = nb - s.bal(a);
                    }
                    s.save();
                  }
                } else {
                  final ok = await s.deleteAcc(a);
                  if (!ok && mounted) snack(context, 'Can\'t delete: it has transactions or is your only account');
                }
              },
              itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'del', child: Text('Delete'))]),
        ])),
    ];
  }

  Future<void> addAccount() async {
    final r = await formDialog(context, 'New account', [F('Name (e.g. PhonePe, HDFC)'), F('Type', choices: const ['Bank', 'UPI', 'Cash']), F('Opening balance', num: true)]);
    if (r == null || r[0].isEmpty) return;
    final kind = r[1].toLowerCase();
    await store.addAcc(Acc(store.nid(), r[0], kind, open: pnum(r[2]) ?? 0));
  }

  // ---------------- Cards ----------------
  List<Widget> cards(Pal p) {
    final s = store;
    final list = s.accs.where((a) => a.kind == 'card').toList();
    return [
      addBtn(p, 'Add credit card', addCard),
      if (list.isEmpty) hint(p, 'Track your credit card limit, usage and due date.'),
      for (final a in list) _card(p, a),
    ];
  }

  Widget _card(Pal p, Acc a) {
    final s = store;
    final used = s.bal(a);
    final avail = a.limit - used;
    final util = a.limit > 0 ? used / a.limit : 0.0;
    final due = s.nextDay(a.due);
    return AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Icon(Icons.credit_card_rounded, color: violet),
        const SizedBox(width: 10),
        Expanded(child: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
        PopupMenuButton<String>(
            color: p.card,
            icon: Icon(Icons.more_vert_rounded, color: p.sub),
            onSelected: (v) async {
              if (v == 'edit') {
                final r = await formDialog(context, 'Edit card', [F('Name', init: a.name), F('Credit limit', num: true, init: trimNum(a.limit)), F('Due day (1-28)', num: true, init: '${a.due}')]);
                if (r != null && r[0].isNotEmpty) {
                  a.name = r[0];
                  a.limit = pnum(r[1]) ?? a.limit;
                  final d = int.tryParse(r[2]);
                  if (d != null && d >= 1 && d <= 28) a.due = d;
                  s.save();
                }
              } else {
                final ok = await s.deleteAcc(a);
                if (!ok && mounted) snack(context, 'Can\'t delete: it has transactions');
              }
            },
            itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'del', child: Text('Delete'))]),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        RingW(util, util > .7 ? red : util > .4 ? org : grn, 90, Text('${(util * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w800))),
        const SizedBox(width: 18),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Used', style: TextStyle(color: p.sub, fontSize: 12)),
          Text(fmt(used), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: red)),
          const SizedBox(height: 4),
          Text('Available ${fmt(avail)} of ${fmt(a.limit)}', style: TextStyle(color: p.sub, fontSize: 13)),
          Text(used > 0 ? 'Due ${due.day} ${mon[due.month - 1]} · ${s.whenText(due)}' : 'Due day: ${a.due}', style: TextStyle(color: p.sub, fontSize: 13)),
        ])),
      ]),
      if (used > 0) ...[
        const SizedBox(height: 12),
        SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
                onPressed: () async {
                  final from = await pickAcc(context, noCard: true, title: 'Pay card bill from');
                  if (from != null && mounted) openAdd(context, type: 't', from: from.id, to: a.id, amount: used);
                },
                icon: const Icon(Icons.payments_rounded),
                label: const Text('Pay bill'))),
      ],
    ]));
  }

  Future<void> addCard() async {
    final r = await formDialog(context, 'New credit card', [F('Card name (e.g. HDFC Regalia)'), F('Credit limit', num: true), F('Amount used so far', num: true), F('Due day of month (1-28)', num: true, init: '5')]);
    if (r == null || r[0].isEmpty) return;
    final d = int.tryParse(r[3]) ?? 5;
    await store.addAcc(Acc(store.nid(), r[0], 'card', open: pnum(r[2]) ?? 0, limit: pnum(r[1]) ?? 0, due: d < 1 ? 1 : d > 28 ? 28 : d));
  }

  // ---------------- Bills ----------------
  List<Widget> bills(Pal p) {
    final s = store;
    return [
      addBtn(p, 'Add recurring bill', addBill),
      if (s.bills.isEmpty) hint(p, 'Add rent, subscriptions, electricity… and get reminded before they are due.'),
      for (final b in s.bills)
        swipe(
            b['i'] as String,
            AppCard(
                child: Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: violet.withOpacity(.14), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.receipt_long_rounded, color: violet)),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${b['n']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('${fmt((b['a'] as num).toDouble())} · day ${b['d']} · ${s.billPaid(b) ? 'Paid ✓' : s.whenText(s.dueOf((b['d'] as num).toInt(), false))}', style: TextStyle(color: !s.billPaid(b) && s.dueOf((b['d'] as num).toInt(), false).isBefore(s.today) ? red : p.sub, fontSize: 13)),
              ])),
              if (!s.billPaid(b))
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
                    onPressed: () async {
                      final a = await pickAcc(context);
                      if (a != null) {
                        await s.payBill(b, a);
                        if (mounted) coinDrop(context);
                      }
                    },
                    child: const Text('Pay')),
            ])),
            () async {
          s.bills.remove(b);
          await s.save();
        }),
    ];
  }

  Future<void> addBill() async {
    final r = await formDialog(context, 'New bill', [F('Name (Rent, Netflix…)'), F('Amount', num: true), F('Due day of month (1-28)', num: true, init: '1')]);
    if (r == null || r[0].isEmpty) return;
    final a = pnum(r[1]), d = int.tryParse(r[2]);
    if (a == null || a <= 0 || d == null || d < 1 || d > 31) return;
    store.bills.add({'i': store.nid(), 'n': r[0], 'a': a, 'd': d, 'p': ''});
    await store.save();
  }

  // ---------------- EMI ----------------
  List<Widget> emis(Pal p) {
    final s = store;
    final active = s.loans.where((l) => !s.loanDone(l)).toList();
    return [
      if (s.loans.isNotEmpty)
        AppCard(
            gradient: heroGrad,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Total still to repay', style: TextStyle(color: Colors.white70)),
              Count(s.loansLeft, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Colors.white)),
              Text('${active.length} active loan${active.length == 1 ? '' : 's'}', style: const TextStyle(color: Colors.white70)),
            ])),
      addBtn(p, 'Add EMI / loan', addLoan),
      if (s.loans.isEmpty) hint(p, 'Track home, car or personal loans with a payoff date and progress bar.'),
      for (final l in s.loans)
        swipe(
            l['i'] as String,
            AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('${l['n']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
                Text('${fmt((l['e'] as num).toDouble())}/mo', style: TextStyle(color: p.sub, fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 10),
              Bar((l['p'] as num) / (l['t'] as num), s.loanDone(l) ? grn : blue, h: 10),
              const SizedBox(height: 8),
              Text(s.loanDone(l) ? 'Fully paid 🎉' : '${(l['t'] as num).toInt() - (l['p'] as num).toInt()} EMIs left · ${fmt(s.loanLeft(l))} remaining', style: const TextStyle(fontWeight: FontWeight.w600)),
              Text(s.loanDone(l) ? 'Loan closed' : 'Payoff by ${mon[s.payoff(l).month - 1]} ${s.payoff(l).year}  ·  ${(l['p'] as num).toInt()}/${(l['t'] as num).toInt()} paid', style: TextStyle(color: p.sub, fontSize: 13)),
              if (!s.loanDone(l)) ...[
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: Text(s.loanPaidNow(l) ? 'This month paid ✓' : 'Next: ${s.nextDay((l['d'] as num).toInt()).day} ${mon[s.nextDay((l['d'] as num).toInt()).month - 1]} · ${s.whenText(s.nextDay((l['d'] as num).toInt()))}', style: TextStyle(color: p.sub, fontSize: 13))),
                  if (!s.loanPaidNow(l))
                    FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
                        onPressed: () async {
                          final a = await pickAcc(context, noCard: true);
                          if (a != null) {
                            await s.payLoan(l, a);
                            if (mounted) coinDrop(context);
                          }
                        },
                        child: const Text('Pay EMI')),
                ]),
              ],
            ])),
            () async {
          s.loans.remove(l);
          await s.save();
        }),
    ];
  }

  Future<void> addLoan() async {
    final r = await formDialog(context, 'New EMI / loan', [F('Name (Home loan, Bike…)'), F('Monthly EMI', num: true), F('Total months', num: true), F('Months already paid', num: true, init: '0'), F('EMI day of month (1-28)', num: true, init: '5')]);
    if (r == null || r[0].isEmpty) return;
    final e = pnum(r[1]), t = int.tryParse(r[2]), pd = int.tryParse(r[3]) ?? 0, d = int.tryParse(r[4]) ?? 5;
    if (e == null || e <= 0 || t == null || t <= 0) return;
    store.loans.add({'i': store.nid(), 'n': r[0], 'e': e, 't': t, 'p': pd > t ? t : pd, 'd': d < 1 ? 1 : d > 28 ? 28 : d, 'm': ''});
    await store.save();
  }

  // ---------------- Udhaar ----------------
  List<Widget> udhaar(Pal p) {
    final s = store;
    final open = s.udhaar.where((u) => u['x'] != true).toList();
    final done = s.udhaar.where((u) => u['x'] == true).toList();
    return [
      Row(children: [
        Expanded(child: AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('You\'ll get', style: TextStyle(color: p.sub)), Count(s.toReceive, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: grn))]))),
        const SizedBox(width: 12),
        Expanded(child: AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('You owe', style: TextStyle(color: p.sub)), Count(s.toPay, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: red))]))),
      ]),
      addBtn(p, 'Add udhaar', addUdhaar),
      if (open.isEmpty) hint(p, 'Keep track of who owes you and who you owe. Set a reminder so it never slips.'),
      for (final u in open) _udhaarTile(p, u),
      if (done.isNotEmpty) ...[
        const Sec('Settled'),
        for (final u in done)
          swipe(
              u['i'] as String,
              AppCard(padding: const EdgeInsets.all(14), child: Row(children: [Icon(Icons.check_circle_rounded, color: p.sub), const SizedBox(width: 10), Expanded(child: Text('${u['w']}', style: TextStyle(color: p.sub))), Text(fmt((u['a'] as num).toDouble()), style: TextStyle(color: p.sub))])),
              () async {
            s.udhaar.remove(u);
            await s.save();
          }),
      ],
    ];
  }

  Widget _udhaarTile(Pal p, Map<String, dynamic> u) {
    final gave = u['k'] == 'gave';
    final r = ((u['r'] ?? 0) as num).toInt();
    final col = gave ? grn : red;
    return swipe(
        u['i'] as String,
        AppCard(
            child: Row(children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(color: col.withOpacity(.14), borderRadius: BorderRadius.circular(14)), child: Icon(gave ? Icons.call_received_rounded : Icons.call_made_rounded, color: col)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${u['w']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            Text(gave ? 'Owes you' : 'You owe', style: TextStyle(color: col, fontSize: 12.5, fontWeight: FontWeight.w600)),
            if (r > 0) Text('Remind ${DateTime.fromMillisecondsSinceEpoch(r).day} ${mon[DateTime.fromMillisecondsSinceEpoch(r).month - 1]}', style: TextStyle(color: p.sub, fontSize: 12)),
            if ('${u['n'] ?? ''}'.isNotEmpty) Text('${u['n']}', style: TextStyle(color: p.sub, fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(fmt((u['a'] as num).toDouble()), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: col)),
            GestureDetector(onTap: () => settle(u), child: Padding(padding: const EdgeInsets.only(top: 6), child: Text('Settle', style: TextStyle(color: p.accent, fontWeight: FontWeight.w800)))),
          ]),
        ])),
        () async {
      store.udhaar.remove(u);
      await store.save();
    });
  }

  Future<void> settle(Map<String, dynamic> u) async {
    final p = Pal.of(context);
    final gave = u['k'] == 'gave';
    final choice = await showDialog<String>(
        context: context,
        builder: (d) => SimpleDialog(
              backgroundColor: p.card,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              title: const Text('Settle udhaar', style: TextStyle(fontWeight: FontWeight.w800)),
              children: [
                SimpleDialogOption(onPressed: () => Navigator.pop(d, 'only'), child: const Text('Just mark as settled')),
                SimpleDialogOption(onPressed: () => Navigator.pop(d, 'rec'), child: Text(gave ? 'Mark settled + add money to an account' : 'Mark settled + pay from an account')),
              ],
            ));
    if (choice == null) return;
    Acc? a;
    if (choice == 'rec') {
      if (!mounted) return;
      a = await pickAcc(context, noCard: !gave, title: gave ? 'Received in' : 'Paid from');
      if (a == null) return;
    }
    await store.settle(u, a);
    if (mounted) snack(context, 'Settled ✓');
  }

  Future<void> addUdhaar() async {
    final r = await formDialog(context, 'New udhaar', [F('Person name'), F('Amount', num: true), F('Type', choices: const ['I gave', 'I owe']), F('Note (optional)'), F('Remind me in … days (optional)', num: true)]);
    if (r == null || r[0].isEmpty) return;
    final a = pnum(r[1]);
    if (a == null || a <= 0) return;
    final days = int.tryParse(r[4]) ?? 0;
    final rem = days > 0 ? DateTime(store.now.year, store.now.month, store.now.day + days, 9).millisecondsSinceEpoch : 0;
    store.udhaar.add({'i': store.nid(), 'w': r[0], 'a': a, 'k': r[2] == 'I gave' ? 'gave' : 'owe', 'n': r[3], 'r': rem, 'x': false});
    await store.save();
  }

  // ---------------- Net worth ----------------
  List<Widget> worth(Pal p) {
    final s = store;
    Widget line(String l, double v, Color c, {bool neg = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(3))),
          const SizedBox(width: 10),
          Expanded(child: Text(l)),
          Text('${neg ? '-' : ''}${fmt(v)}', style: TextStyle(fontWeight: FontWeight.w800, color: neg ? red : p.text)),
        ]));
    return [
      AppCard(
          gradient: heroGrad,
          padding: const EdgeInsets.all(22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Your net worth', style: TextStyle(color: Colors.white70)),
            Shine(child: Count(s.netWorth, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800, color: Colors.white))),
          ])),
      AppCard(
          child: Column(children: [
        line('Bank, cash & UPI', s.liquid, grn),
        line('Investments (FD, gold, SIP…)', s.assetsTotal, blue),
        line('Money to receive', s.toReceive, org),
        const Divider(),
        line('Credit card dues', s.cardUsed, red, neg: true),
        line('Loans left', s.loansLeft, red, neg: true),
        line('Money you owe', s.toPay, red, neg: true),
      ])),
      Sec('Investments & assets', trail: IconButton(onPressed: addAsset, icon: Icon(Icons.add_circle_rounded, color: p.accent))),
      if (s.assets.isEmpty) hint(p, 'Add your FD, gold, SIP, PPF… to see the full picture.'),
      for (final a in s.assets)
        swipe(
            a['i'] as String,
            AppCard(
                onTap: () async {
                  final r = await formDialog(context, 'Update value', [F('Current value', num: true, init: trimNum((a['v'] as num).toDouble()))]);
                  final v = r == null ? null : pnum(r[0]);
                  if (v != null) {
                    a['v'] = v;
                    store.save();
                  }
                },
                child: Row(children: [
                  Icon(a['k'] == 'Gold' ? Icons.diamond_rounded : a['k'] == 'SIP' ? Icons.trending_up_rounded : Icons.account_balance_rounded, color: p.accent),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${a['n']}', style: const TextStyle(fontWeight: FontWeight.w800)), Text('${a['k']} · tap to update', style: TextStyle(color: p.sub, fontSize: 12))])),
                  Text(fmt((a['v'] as num).toDouble()), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                ])),
            () async {
          s.assets.remove(a);
          await s.save();
        }),
    ];
  }

  Future<void> addAsset() async {
    final r = await formDialog(context, 'New asset', [F('Name (SBI FD, Gold coins…)'), F('Type', choices: const ['FD', 'Gold', 'SIP', 'Other']), F('Current value', num: true)]);
    if (r == null || r[0].isEmpty) return;
    final v = pnum(r[2]);
    if (v == null) return;
    store.assets.add({'i': store.nid(), 'n': r[0], 'k': r[1], 'v': v});
    await store.save();
  }

  // ---------------- Goals ----------------
  List<Widget> goals(Pal p) {
    final s = store;
    return [
      addBtn(p, 'New savings goal', addGoal),
      if (s.goals.isEmpty) hint(p, 'Save for a trip, phone or emergency fund. Set a deadline and see how much to save each month.'),
      for (final g in s.goals)
        swipe(
            g['i'] as String,
            Builder(builder: (context) {
              final t = (g['t'] as num).toDouble(), sv = (g['s'] as num).toDouble();
              final r = t == 0 ? 0.0 : sv / t;
              final dl = ((g['dl'] ?? 0) as num).toInt();
              final m = s.goalMonthly(g);
              return AppCard(
                  child: Row(children: [
                RingW(r, grn, 78, Text('${(r * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14))),
                const SizedBox(width: 16),
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${g['n']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  Text('${fmt(sv)} of ${fmt(t)}', style: TextStyle(color: p.sub)),
                  if (dl > 0) Text('By ${mon[DateTime.fromMillisecondsSinceEpoch(dl).month - 1]} ${DateTime.fromMillisecondsSinceEpoch(dl).year}${m > 0 ? ' · save ${fmt(m)}/month' : ''}', style: TextStyle(color: p.accent, fontSize: 12.5, fontWeight: FontWeight.w600)),
                ])),
                TextButton(onPressed: () => fundGoal(g), child: Text('Add', style: TextStyle(color: p.accent, fontWeight: FontWeight.w800))),
              ]));
            }),
            () async {
          s.goals.remove(g);
          await s.save();
        }),
    ];
  }

  Future<void> addGoal() async {
    final r = await formDialog(context, 'New goal', [F('Goal name'), F('Target amount', num: true), F('Months to reach it (optional)', num: true)]);
    if (r == null || r[0].isEmpty) return;
    final t = pnum(r[1]);
    if (t == null || t <= 0) return;
    final mo = int.tryParse(r[2]) ?? 0;
    final n = store.now;
    store.goals.add({'i': store.nid(), 'n': r[0], 't': t, 's': 0.0, 'dl': mo > 0 ? DateTime(n.year, n.month + mo, n.day).millisecondsSinceEpoch : 0});
    await store.save();
  }

  Future<void> fundGoal(Map<String, dynamic> g) async {
    final r = await formDialog(context, 'Add to ${g['n']}', [F('Amount', num: true)], ok: 'Add');
    final v = r == null ? null : pnum(r[0]);
    if (v == null || v <= 0) return;
    if (!mounted) return;
    final a = await pickAcc(context, noCard: true, title: 'Save from');
    if (a == null) return;
    final done = await store.fund(g, v, a);
    if (done && mounted) {
      HapticFeedback.heavyImpact();
      confetti(context);
      snack(context, 'Goal reached! 🎉');
    } else if (mounted) {
      coinDrop(context);
    }
  }

  // ---------------- Budgets ----------------
  List<Widget> budgets(Pal p) {
    final s = store;
    return [
      Padding(padding: const EdgeInsets.only(bottom: 12), child: Text('Tap a category to set its monthly limit. Use 0 to remove.', style: TextStyle(color: p.sub))),
      AppCard(
          child: Column(children: [
        for (final c in expCats.where((c) => c.grp != 's'))
          Builder(builder: (context) {
            final sp = s.spentCat(c.name);
            final l = s.budgets[c.name] == null ? null : (s.budgets[c.name] as num).toDouble();
            final r = (l == null || l == 0) ? 0.0 : sp / l;
            return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () async {
                  final res = await formDialog(context, 'Limit · ${c.name}', [F('Monthly limit', num: true, init: l == null ? '' : trimNum(l))]);
                  final v = res == null ? null : pnum(res[0]);
                  if (v == null) return;
                  if (v == 0) {
                    s.budgets.remove(c.name);
                  } else {
                    s.budgets[c.name] = v;
                  }
                  s.save();
                },
                child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Icon(c.icon, size: 18, color: c.color),
                        const SizedBox(width: 8),
                        Expanded(child: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700))),
                        Text(l == null ? '${fmt(sp)} · set limit' : '${fmt(sp)} / ${fmt(l)}', style: TextStyle(color: r >= 1 ? red : p.sub, fontSize: 13)),
                      ]),
                      const SizedBox(height: 7),
                      Bar(r, r < .8 ? grn : r < 1 ? org : red),
                    ])));
          }),
      ])),
    ];
  }

  @override
  Widget build(BuildContext context) => Live((context) {
        final p = Pal.of(context);
        final body = <List<Widget> Function(Pal)>[accounts, cards, bills, emis, udhaar, worth, goals, budgets][sec](p);
        return ListView(physics: bounce, padding: pagePad, children: [
          const PageTitle('Money'),
          SizedBox(
              height: 44,
              child: ListView(scrollDirection: Axis.horizontal, children: [for (var i = 0; i < _secs.length; i++) Padding(padding: const EdgeInsets.only(right: 8), child: Pill(_secs[i], sec == i, () => setState(() => sec = i)))])),
          const SizedBox(height: 14),
          AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: Column(key: ValueKey(sec), crossAxisAlignment: CrossAxisAlignment.start, children: body)),
        ]);
      });
}
