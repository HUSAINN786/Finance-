import 'package:flutter/material.dart';
import 'core.dart';
import 'ui.dart';

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context) => Live((context) {
        final p = Pal.of(context);
        final s = store;
        if (s.txs.isEmpty) {
          return const EmptyState(Icons.insights_rounded, 'No reports yet', 'Add a few transactions and your charts will draw themselves here.');
        }
        // category donut for this cycle
        final names = <String>[], vals = <double>[], cols = <Color>[];
        for (final c in expCats) {
          final v = s.sumTx((t) => s.isSpend(t) && t.cat == c.name && s.inCycle(t));
          if (v > 0) {
            names.add(c.name);
            vals.add(v);
            cols.add(c.color);
          }
        }
        final total = vals.fold<double>(0, (a, b) => a + b);
        // 6 cycle trend
        final inc = <double>[], exp = <double>[], labels = <String>[];
        for (var k = 5; k >= 0; k--) {
          final a = s.cycStartK(k), b = s.cycEndK(k);
          inc.add(s.sumIn(a, b, (t) => t.type == 'i'));
          exp.add(s.sumIn(a, b, (t) => s.isSpend(t)));
          labels.add(mon[a.month - 1]);
        }
        // top spends
        final top = s.txs.where((t) => s.isSpend(t) && s.inCycle(t)).toList()..sort((a, b) => b.amt.compareTo(a.amt));
        // heatmap: last 5 weeks
        final ds = s.daySpend();
        final t0 = s.today;
        final mon0 = DateTime(t0.year, t0.month, t0.day - (t0.weekday - 1));
        final cells = <List<double>>[];
        var mx = 1.0;
        final wdTot = List<double>.filled(7, 0);
        for (var w = 4; w >= 0; w--) {
          final row = <double>[];
          for (var d = 0; d < 7; d++) {
            final day = DateTime(mon0.year, mon0.month, mon0.day - 7 * w + d);
            if (day.isAfter(t0)) {
              row.add(-1);
            } else {
              final v = ds['${day.year}-${day.month}-${day.day}'] ?? 0;
              row.add(v);
              wdTot[d] += v;
              if (v > mx) mx = v;
            }
          }
          cells.add(row);
        }
        var maxD = 0;
        for (var d = 1; d < 7; d++) {
          if (wdTot[d] > wdTot[maxD]) maxD = d;
        }
        const full = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        var i = 0;
        return ListView(physics: bounce, padding: pagePad, children: [
          Pop(i++, PageTitle('Reports', sub: '${s.cStart.day} ${mon[s.cStart.month - 1]} – ${s.cEnd.day} ${mon[s.cEnd.month - 1]}')),
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Where your money went', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 16),
                if (total <= 0)
                  Padding(padding: const EdgeInsets.all(20), child: Center(child: Text('No spending this cycle yet', style: TextStyle(color: p.sub))))
                else ...[
                  Center(
                      child: SizedBox(
                          width: 190,
                          height: 190,
                          child: TweenAnimationBuilder<double>(
                              tween: Tween<double>(begin: 0, end: 1),
                              duration: const Duration(milliseconds: 1300),
                              curve: Curves.easeOutCubic,
                              builder: (_, t, __) => CustomPaint(
                                  painter: DonutPainter(vals, cols, t, p.line),
                                  child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text('Spent', style: TextStyle(color: p.sub, fontSize: 12)), Text(fmt(total * t), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))])))))),
                  const SizedBox(height: 16),
                  for (var k = 0; k < names.length; k++)
                    Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(children: [
                          Container(width: 12, height: 12, decoration: BoxDecoration(color: cols[k], borderRadius: BorderRadius.circular(4))),
                          const SizedBox(width: 10),
                          Expanded(child: Text(names[k], style: const TextStyle(fontWeight: FontWeight.w600))),
                          Text('${(vals[k] / total * 100).round()}%', style: TextStyle(color: p.sub)),
                          const SizedBox(width: 12),
                          Text(fmt(vals[k]), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ])),
                ],
              ]))),
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Expanded(child: Text('6-month trend', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                  Container(width: 10, height: 10, decoration: BoxDecoration(color: grn, borderRadius: BorderRadius.circular(3))),
                  const SizedBox(width: 5),
                  Text('Income', style: TextStyle(color: p.sub, fontSize: 12)),
                  const SizedBox(width: 12),
                  Container(width: 10, height: 10, decoration: BoxDecoration(color: red, borderRadius: BorderRadius.circular(3))),
                  const SizedBox(width: 5),
                  Text('Spent', style: TextStyle(color: p.sub, fontSize: 12)),
                ]),
                const SizedBox(height: 16),
                SizedBox(
                    height: 170,
                    width: double.infinity,
                    child: TweenAnimationBuilder<double>(
                        tween: Tween<double>(begin: 0, end: 1),
                        duration: const Duration(milliseconds: 1100),
                        curve: Curves.easeOutCubic,
                        builder: (_, t, __) => CustomPaint(painter: TrendPainter(inc, exp, labels, t, grn, red, p.sub, p.line)))),
              ]))),
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Top spends this cycle', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 10),
                if (top.isEmpty) Text('Nothing yet', style: TextStyle(color: p.sub)),
                for (var k = 0; k < top.length && k < 5; k++)
                  Padding(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: Row(children: [
                        Container(width: 36, height: 36, decoration: BoxDecoration(color: catOf(top[k].cat).color.withOpacity(.14), borderRadius: BorderRadius.circular(12)), child: Icon(catOf(top[k].cat).icon, size: 19, color: catOf(top[k].cat).color)),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(top[k].note.isEmpty ? top[k].cat : top[k].note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), Text('${top[k].date.day} ${mon[top[k].date.month - 1]} · ${top[k].cat}', style: TextStyle(color: p.sub, fontSize: 12))])),
                        Text(fmt(top[k].amt), style: const TextStyle(fontWeight: FontWeight.w800)),
                      ])),
              ]))),
          Pop(
              i++,
              AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Weekday heatmap', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('Last 5 weeks · darker = more spent', style: TextStyle(color: p.sub, fontSize: 12.5)),
                const SizedBox(height: 14),
                Row(children: [for (final d in wdn) Expanded(child: Center(child: Text(d.substring(0, 1), style: TextStyle(color: p.sub, fontWeight: FontWeight.w700))))]),
                const SizedBox(height: 6),
                for (final row in cells)
                  Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(children: [
                        for (final v in row)
                          Expanded(
                              child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 3),
                                  child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 600),
                                      height: 38,
                                      decoration: BoxDecoration(color: v < 0 ? p.chip.withOpacity(.4) : v == 0 ? p.chip : p.accent.withOpacity(.2 + .8 * (v / mx).clamp(0.0, 1.0).toDouble()), borderRadius: BorderRadius.circular(10))))),
                      ])),
                if (wdTot[maxD] > 0) ...[
                  const SizedBox(height: 8),
                  Text('${full[maxD]} is your costliest day — ${fmt(wdTot[maxD] / 5)} on average.', style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ]))),
        ]);
      });
}
