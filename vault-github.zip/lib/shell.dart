import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'add_sheet.dart';
import 'core.dart';
import 'history.dart';
import 'home.dart';
import 'money.dart';
import 'notif.dart';
import 'profile.dart';
import 'reports.dart';
import 'ui.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellS();
}

class _ShellS extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    Notif.tap.addListener(onTap);
    WidgetsBinding.instance.addPostFrameCallback((_) => onTap());
  }

  @override
  void dispose() {
    Notif.tap.removeListener(onTap);
    super.dispose();
  }

  void onTap() {
    final v = Notif.tap.value;
    if (v == null || !mounted) return;
    Notif.tap.value = null;
    if (v == 'add') {
      openAdd(context);
    } else if (v == 'money') {
      setState(() => tab = 3);
    }
  }

  void go(int i) => setState(() => tab = i);

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final pages = <Widget>[HomePage(goTab: go), const HistoryPage(), const ReportsPage(), const MoneyPage(), const ProfilePage()];
    return Scaffold(
      body: SafeArea(
          bottom: false,
          child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              transitionBuilder: (child, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, .025), end: Offset.zero).animate(a), child: child)),
              child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]))),
      floatingActionButton: Container(
          decoration: BoxDecoration(shape: BoxShape.circle, gradient: const LinearGradient(colors: [goldL, Color(0xFFC8962B)], begin: Alignment.topLeft, end: Alignment.bottomRight), boxShadow: [BoxShadow(color: p.accent.withOpacity(.45), blurRadius: 18, offset: const Offset(0, 8))]),
          child: FloatingActionButton(
              elevation: 0,
              backgroundColor: Colors.transparent,
              foregroundColor: navy,
              shape: const CircleBorder(),
              onPressed: () {
                HapticFeedback.lightImpact();
                openAdd(context);
              },
              child: const Icon(Icons.add_rounded, size: 32))),
      bottomNavigationBar: _NavBar(tab, go),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int sel;
  final void Function(int) onSel;
  const _NavBar(this.sel, this.onSel);
  static const items = [
    [Icons.home_rounded, 'Home'],
    [Icons.receipt_long_rounded, 'History'],
    [Icons.insights_rounded, 'Reports'],
    [Icons.account_balance_wallet_rounded, 'Money'],
    [Icons.person_rounded, 'Profile'],
  ];
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
        decoration: BoxDecoration(color: p.card, border: Border(top: BorderSide(color: p.line)), boxShadow: p.isDark ? null : const [BoxShadow(color: Color(0x101B2440), blurRadius: 20, offset: Offset(0, -6))]),
        padding: EdgeInsets.fromLTRB(10, 8, 10, 8 + MediaQuery.of(context).padding.bottom),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          for (var i = 0; i < items.length; i++)
            GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  HapticFeedback.selectionClick();
                  onSel(i);
                },
                child: AnimatedContainer(
                    duration: const Duration(milliseconds: 320),
                    curve: Curves.easeOutCubic,
                    padding: EdgeInsets.symmetric(horizontal: i == sel ? 14 : 12, vertical: 10),
                    decoration: BoxDecoration(color: i == sel ? p.accent.withOpacity(.16) : Colors.transparent, borderRadius: BorderRadius.circular(22)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      AnimatedScale(scale: i == sel ? 1.12 : 1, duration: const Duration(milliseconds: 280), child: Icon(items[i][0] as IconData, size: 24, color: i == sel ? p.accent : p.sub)),
                      AnimatedSize(
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeOutCubic,
                          child: i == sel ? Padding(padding: const EdgeInsets.only(left: 6), child: Text(items[i][1] as String, style: TextStyle(color: p.accent, fontWeight: FontWeight.w800, fontSize: 13))) : const SizedBox.shrink()),
                    ]))),
        ]));
  }
}
