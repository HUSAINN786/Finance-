import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';
import 'core.dart';
import 'notif.dart';
import 'setup.dart';
import 'shell.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Notif.init();
  store.load();
  runApp(const App());
}

ThemeData buildTheme(bool dark) {
  final p = dark ? Pal.dark : Pal.light;
  final base = ThemeData(useMaterial3: true, brightness: dark ? Brightness.dark : Brightness.light);
  return base.copyWith(
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    colorScheme: (dark ? const ColorScheme.dark() : const ColorScheme.light()).copyWith(primary: p.accent, secondary: p.accent, surface: p.card, onSurface: p.text),
    textTheme: base.textTheme.apply(bodyColor: p.text, displayColor: p.text),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {TargetPlatform.android: CupertinoPageTransitionsBuilder()}),
    snackBarTheme: SnackBarThemeData(backgroundColor: dark ? p.chip : navy, contentTextStyle: const TextStyle(color: Colors.white)),
  );
}

final ThemeData _light = buildTheme(false);
final ThemeData _dark = buildTheme(true);

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: store,
      builder: (c, _) => MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Vault',
            theme: _light,
            darkTheme: _dark,
            themeMode: store.mode,
            home: const Splash(),
          ));
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashS();
}

class _SplashS extends State<Splash> {
  @override
  void initState() {
    super.initState();
    go();
  }

  Future<void> go() async {
    await Future.delayed(const Duration(milliseconds: 1700));
    while (!store.ready) {
      await Future.delayed(const Duration(milliseconds: 50));
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (_, __, ___) => const Root(),
        transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c)));
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Scaffold(
        body: Center(
            child: TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: 1),
                duration: const Duration(milliseconds: 1200),
                curve: Curves.elasticOut,
                builder: (_, v, ch) => Opacity(opacity: c01(v), child: Transform.scale(scale: v, child: ch)),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Logo(100),
                  const SizedBox(height: 18),
                  const Text('Vault', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: 2)),
                  const SizedBox(height: 4),
                  Text('Your money, in order', style: TextStyle(color: p.sub)),
                ]))));
  }
}

class Root extends StatelessWidget {
  const Root({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: store,
      builder: (c, _) => AnimatedSwitcher(duration: const Duration(milliseconds: 500), child: store.setupDone ? const Shell(key: ValueKey('shell')) : const SetupScreen(key: ValueKey('setup'))));
}
