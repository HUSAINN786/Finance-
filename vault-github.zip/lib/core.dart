import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'notif.dart';

const cur = '₹';
const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const wdn = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const grn = Color(0xFF22B07D);
const red = Color(0xFFE5484D);
const org = Color(0xFFF59E0B);
const navy = Color(0xFF1B2440);
const goldL = Color(0xFFE9C46A);
const goldD = Color(0xFFB8860B);
const violet = Color(0xFF8B5CF6);
const blue = Color(0xFF3B82F6);

String groupIN(String s) {
  if (s.length <= 3) return s;
  final last = s.substring(s.length - 3);
  var rest = s.substring(0, s.length - 3);
  final parts = <String>[];
  while (rest.length > 2) {
    parts.insert(0, rest.substring(rest.length - 2));
    rest = rest.substring(0, rest.length - 2);
  }
  if (rest.isNotEmpty) parts.insert(0, rest);
  return '${parts.join(',')},$last';
}

String fmt(double v) {
  final r = v.isNaN || v.isInfinite ? 0 : v.round();
  return (r < 0 ? '-' : '') + cur + groupIN(r.abs().toString());
}

String short(double v) {
  final a = v.abs();
  if (a >= 10000000) return '${(v / 10000000).toStringAsFixed(1)}Cr';
  if (a >= 100000) return '${(v / 100000).toStringAsFixed(1)}L';
  if (a >= 1000) return '${(v / 1000).toStringAsFixed(a >= 10000 ? 0 : 1)}k';
  return v.round().toString();
}

String trimNum(double v) => v == v.roundToDouble() ? v.round().toString() : v.toStringAsFixed(2);
double? pnum(String s) => double.tryParse(s.replaceAll(',', '').trim());
double c01(double v) => (v.isNaN) ? 0.0 : v.clamp(0.0, 1.0).toDouble();

class Pal {
  final bool isDark;
  final Color bg, card, text, sub, line, accent, chip;
  const Pal(this.isDark, this.bg, this.card, this.text, this.sub, this.line, this.accent, this.chip);
  static const light = Pal(false, Color(0xFFFBF7EE), Colors.white, Color(0xFF1B2440), Color(0xFF7C8299), Color(0xFFEFE8D6), Color(0xFFC8962B), Color(0xFFF4EEDD));
  static const dark = Pal(true, Color(0xFF0D111E), Color(0xFF171C2E), Color(0xFFF5F2E9), Color(0xFF9AA1B8), Color(0xFF262D47), Color(0xFFE6B84A), Color(0xFF222942));
  static Pal of(BuildContext c) => Theme.of(c).brightness == Brightness.dark ? dark : light;
  Color get onAccent => isDark ? const Color(0xFF14151C) : Colors.white;
  List<BoxShadow> get shadow => isDark ? const [] : const [BoxShadow(color: Color(0x141B2440), blurRadius: 20, offset: Offset(0, 8))];
}

class Cat {
  final String name, grp;
  final IconData icon;
  final Color color;
  const Cat(this.name, this.icon, this.color, this.grp);
}

const expCats = [
  Cat('Food', Icons.restaurant_rounded, org, 'n'),
  Cat('Travel', Icons.directions_bus_rounded, blue, 'n'),
  Cat('Bills', Icons.receipt_long_rounded, violet, 'n'),
  Cat('Rent', Icons.home_rounded, Color(0xFF0EA5A5), 'n'),
  Cat('EMI', Icons.account_balance_rounded, red, 'n'),
  Cat('Health', Icons.favorite_rounded, Color(0xFFEC4899), 'n'),
  Cat('Shopping', Icons.shopping_bag_rounded, Color(0xFF6366F1), 'w'),
  Cat('Fun', Icons.movie_rounded, Color(0xFF14B8A6), 'w'),
  Cat('Other', Icons.category_rounded, Color(0xFF94A3B8), 'w'),
  Cat('Savings', Icons.savings_rounded, grn, 's'),
];
const incCats = [
  Cat('Salary', Icons.payments_rounded, grn, 'i'),
  Cat('Bonus', Icons.stars_rounded, org, 'i'),
  Cat('Freelance', Icons.work_rounded, blue, 'i'),
  Cat('Gift', Icons.card_giftcard_rounded, Color(0xFFEC4899), 'i'),
  Cat('Other', Icons.category_rounded, Color(0xFF94A3B8), 'i'),
];
const _extra = [
  Cat('ATM', Icons.atm_rounded, Color(0xFFC8962B), 't'),
  Cat('Transfer', Icons.swap_horiz_rounded, blue, 't'),
  Cat('Income', Icons.payments_rounded, grn, 'i'),
];

Cat catOf(String n) {
  for (final c in expCats) {
    if (c.name == n) return c;
  }
  for (final c in incCats) {
    if (c.name == n) return c;
  }
  for (final c in _extra) {
    if (c.name == n) return c;
  }
  return Cat(n, Icons.category_rounded, const Color(0xFF94A3B8), 'w');
}

IconData accIcon(String k) {
  switch (k) {
    case 'bank':
      return Icons.account_balance_rounded;
    case 'cash':
      return Icons.payments_rounded;
    case 'upi':
      return Icons.qr_code_2_rounded;
    default:
      return Icons.credit_card_rounded;
  }
}

class Acc {
  String id, name, kind;
  double open, limit;
  int due;
  Acc(this.id, this.name, this.kind, {this.open = 0, this.limit = 0, this.due = 1});
  Map<String, dynamic> toJ() => {'i': id, 'n': name, 'k': kind, 'o': open, 'l': limit, 'd': due};
  factory Acc.fromJ(Map j) => Acc(j['i'], j['n'], j['k'],
      open: ((j['o'] ?? 0) as num).toDouble(), limit: ((j['l'] ?? 0) as num).toDouble(), due: ((j['d'] ?? 1) as num).toInt());
}

class Tx {
  String id, type, cat, note, acc, to;
  double amt;
  DateTime date;
  List<String> tags;
  Tx({required this.id, required this.type, required this.amt, required this.cat, this.note = '', required this.acc, this.to = '', required this.date, List<String>? tags})
      : tags = tags ?? [];
  Map<String, dynamic> toJ() => {'i': id, 't': type, 'a': amt, 'c': cat, 'n': note, 'ac': acc, 'to': to, 'd': date.millisecondsSinceEpoch, 'tg': tags};
  factory Tx.fromJ(Map j) => Tx(
      id: j['i'],
      type: j['t'],
      amt: (j['a'] as num).toDouble(),
      cat: j['c'],
      note: (j['n'] ?? '') as String,
      acc: j['ac'],
      to: (j['to'] ?? '') as String,
      date: DateTime.fromMillisecondsSinceEpoch(j['d'] as int),
      tags: List<String>.from((j['tg'] ?? []) as List));
}

class Insight {
  final IconData icon;
  final Color color;
  final String text;
  const Insight(this.icon, this.color, this.text);
}

class DueItem {
  final String title;
  final double amt;
  final DateTime date;
  final IconData icon;
  final Color color;
  const DueItem(this.title, this.amt, this.date, this.icon, this.color);
}

Map<String, dynamic> defNotif() => {
      'bill': {'on': false, 'h': 9, 'm': 0},
      'budget': {'on': false},
      'salary': {'on': false, 'h': 9, 'm': 0},
      'cash': {'on': false, 'v': 500},
      'daily': {'on': false, 'h': 21, 'm': 0},
    };

List<Map<String, dynamic>> _lm(dynamic v) => ((v ?? []) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

final store = Store();

class Store extends ChangeNotifier {
  bool ready = false, setupDone = false;
  String name = '', themeMode = 'light', snooze = '';
  double salary = 0;
  int payday = 1;
  List<Acc> accs = [];
  List<Tx> txs = [];
  List<Map<String, dynamic>> goals = [], bills = [], loans = [], udhaar = [], assets = [];
  Map<String, dynamic> budgets = {};
  Map<String, dynamic> notif = defNotif();
  int _c = 0;

  String nid() => DateTime.now().microsecondsSinceEpoch.toRadixString(36) + (_c++).toString();

  ThemeMode get mode => themeMode == 'dark' ? ThemeMode.dark : themeMode == 'system' ? ThemeMode.system : ThemeMode.light;

  // ---------- persistence ----------
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('db');
    if (s != null) {
      try {
        fromMap(jsonDecode(s) as Map);
      } catch (_) {}
    }
    ready = true;
    notifyListeners();
    reschedule();
  }

  void fromMap(Map m) {
    payday = ((m['pd'] ?? 1) as num).toInt();
    budgets = Map<String, dynamic>.from((m['bu'] ?? {}) as Map);
    goals = _lm(m['g']);
    bills = _lm(m['b']);
    loans = _lm(m['l']);
    udhaar = _lm(m['u']);
    assets = _lm(m['as']);
    for (final l in [goals, bills, loans, udhaar, assets]) {
      for (final x in l) {
        x.putIfAbsent('i', () => nid());
      }
    }
    if (m['v'] == null) {
      accs = [Acc('bank', 'Bank', 'bank'), Acc('cash', 'Cash', 'cash')];
      txs = ((m['tx'] ?? []) as List).map((e) {
        final j = e as Map;
        final d = DateTime.fromMillisecondsSinceEpoch(j['d'] as int);
        final a = (j['a'] as num).toDouble();
        if (j['t'] == 'a') {
          return Tx(id: nid(), type: 't', amt: a, cat: 'ATM', note: (j['n'] ?? '') as String, acc: 'bank', to: 'cash', date: d);
        }
        return Tx(id: nid(), type: j['t'] as String, amt: a, cat: j['c'] as String, note: (j['n'] ?? '') as String, acc: j['h'] == true ? 'cash' : 'bank', date: d);
      }).toList();
      setupDone = false;
    } else {
      setupDone = m['su'] == true;
      name = (m['nm'] ?? '') as String;
      salary = ((m['sal'] ?? 0) as num).toDouble();
      themeMode = (m['th'] ?? 'light') as String;
      snooze = (m['sn'] ?? '') as String;
      accs = ((m['ac'] ?? []) as List).map((e) => Acc.fromJ(e as Map)).toList();
      txs = ((m['tx'] ?? []) as List).map((e) => Tx.fromJ(e as Map)).toList();
      final n = defNotif();
      if (m['nt'] is Map) {
        (m['nt'] as Map).forEach((k, v) {
          if (v is Map) n[k.toString()] = Map<String, dynamic>.from(v);
        });
      }
      notif = n;
    }
    txs.sort((a, b) => b.date.compareTo(a.date));
  }

  Map<String, dynamic> toMap() => {
        'v': 3,
        'su': setupDone,
        'nm': name,
        'sal': salary,
        'th': themeMode,
        'sn': snooze,
        'pd': payday,
        'nt': notif,
        'ac': accs.map((e) => e.toJ()).toList(),
        'tx': txs.map((e) => e.toJ()).toList(),
        'g': goals,
        'b': bills,
        'l': loans,
        'u': udhaar,
        'as': assets,
        'bu': budgets,
      };

  Future<void> save() async {
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('db', jsonEncode(toMap()));
    reschedule();
  }

  Future<void> resetAll() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('db');
    setupDone = false;
    name = '';
    salary = 0;
    payday = 1;
    accs = [];
    txs = [];
    goals = [];
    bills = [];
    loans = [];
    udhaar = [];
    assets = [];
    budgets = {};
    notif = defNotif();
    snooze = '';
    notifyListeners();
    await Notif.cancelAll();
  }

  // ---------- setup / profile ----------
  Future<void> finishSetup(String n, double sal, int pd, double bank, double cash, bool remind) async {
    name = n;
    salary = sal;
    payday = pd;
    var b = accById('bank');
    if (b == null) {
      b = Acc('bank', 'Bank', 'bank');
      accs.add(b);
    }
    var c = accById('cash');
    if (c == null) {
      c = Acc('cash', 'Cash', 'cash');
      accs.add(c);
    }
    b.open = 0;
    b.open = bank - bal(b);
    c.open = 0;
    c.open = cash - bal(c);
    setupDone = true;
    if (remind) {
      final ok = await Notif.askPermission();
      if (ok) {
        for (final k in ['bill', 'budget', 'salary', 'cash', 'daily']) {
          (notif[k] as Map)['on'] = true;
        }
      }
    }
    await save();
  }

  Future<void> setMode(String m) async {
    themeMode = m;
    await save();
  }

  bool on(String k) => notif[k] is Map && (notif[k] as Map)['on'] == true;

  Future<bool> toggleNotif(String k, bool v) async {
    if (v) {
      final ok = await Notif.askPermission();
      if (!ok) return false;
    }
    (notif[k] as Map)['on'] = v;
    await save();
    return true;
  }

  Future<void> setNotifTime(String k, int h, int m) async {
    (notif[k] as Map)['h'] = h;
    (notif[k] as Map)['m'] = m;
    await save();
  }

  Future<void> setLowCash(double v) async {
    (notif['cash'] as Map)['v'] = v;
    await save();
  }

  // ---------- accounts ----------
  Acc? accById(String id) {
    for (final a in accs) {
      if (a.id == id) return a;
    }
    return null;
  }

  Acc get defAcc {
    for (final a in accs) {
      if (a.kind == 'bank') return a;
    }
    return accs.first;
  }

  double delta(Acc a, Tx t) {
    final card = a.kind == 'card';
    double d = 0;
    if (t.acc == a.id) {
      if (t.type == 'e') d += card ? t.amt : -t.amt;
      if (t.type == 'i') d += card ? -t.amt : t.amt;
      if (t.type == 't') d += card ? t.amt : -t.amt;
    }
    if (t.type == 't' && t.to == a.id) d += card ? -t.amt : t.amt;
    return d;
  }

  double bal(Acc a) {
    var b = a.open;
    for (final t in txs) {
      b += delta(a, t);
    }
    return b;
  }

  double get liquid {
    var s = 0.0;
    for (final a in accs) {
      if (a.kind != 'card') s += bal(a);
    }
    return s;
  }

  double get cashBal {
    var s = 0.0;
    for (final a in accs) {
      if (a.kind == 'cash') s += bal(a);
    }
    return s;
  }

  double get cardUsed {
    var s = 0.0;
    for (final a in accs) {
      if (a.kind == 'card') s += bal(a);
    }
    return s;
  }

  Future<void> addAcc(Acc a) async {
    accs.add(a);
    await save();
  }

  Future<bool> deleteAcc(Acc a) async {
    if (accs.length <= 1) return false;
    if (txs.any((t) => t.acc == a.id || t.to == a.id)) return false;
    accs.remove(a);
    await save();
    return true;
  }

  // ---------- transactions ----------
  Future<void> addTx(Tx t) async {
    txs.add(t);
    txs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    _alerts(t);
  }

  Future<void> updateTx(Tx old, Tx nu) async {
    final i = txs.indexWhere((x) => x.id == old.id);
    if (i < 0) return;
    txs[i] = nu;
    txs.sort((a, b) => b.date.compareTo(a.date));
    await save();
  }

  Future<void> deleteTx(Tx t) async {
    txs.removeWhere((x) => x.id == t.id);
    await save();
  }

  Future<void> restoreTx(Tx t) async {
    txs.add(t);
    txs.sort((a, b) => b.date.compareTo(a.date));
    await save();
  }

  void _alerts(Tx t) {
    try {
      if (t.type == 'e' && on('budget') && inCycle(t)) {
        final lim = budgets[t.cat];
        if (lim != null) {
          final l = (lim as num).toDouble();
          if (l > 0) {
            final sp = spentCat(t.cat);
            if (sp / l >= .8 && (sp - t.amt) / l < .8) {
              Notif.show(10, '${t.cat} budget at ${(sp / l * 100).round()}%', 'You have used ${fmt(sp)} of your ${fmt(l)} limit.', payload: 'open');
            }
          }
        }
      }
      if (on('cash')) {
        final a = accById(t.acc), b = accById(t.to);
        if ((a != null && a.kind == 'cash') || (b != null && b.kind == 'cash')) {
          final v = ((notif['cash'] as Map)['v'] as num).toDouble();
          if (cashBal < v) Notif.show(11, 'Cash is running low', 'Only ${fmt(cashBal)} left in hand. Time for an ATM visit?', payload: 'open');
        }
      }
    } catch (_) {}
  }

  // ---------- cycle ----------
  DateTime get now => DateTime.now();
  DateTime get today => DateTime(now.year, now.month, now.day);
  DateTime get cStart {
    var d = DateTime(now.year, now.month, payday);
    if (d.isAfter(now)) d = DateTime(now.year, now.month - 1, payday);
    return d;
  }

  DateTime get cEnd => DateTime(cStart.year, cStart.month + 1, payday);
  DateTime cycStartK(int k) => DateTime(cStart.year, cStart.month - k, payday);
  DateTime cycEndK(int k) => DateTime(cStart.year, cStart.month - k + 1, payday);
  int get totalDays => cEnd.difference(cStart).inDays;
  int get daysLeft {
    final d = cEnd.difference(today).inDays;
    return d < 1 ? 1 : d;
  }

  int get daysDone {
    final d = today.difference(cStart).inDays + 1;
    return d < 1 ? 1 : d;
  }

  bool inCycle(Tx t) => !t.date.isBefore(cStart) && t.date.isBefore(cEnd);
  bool isSpend(Tx t) => t.type == 'e' && t.cat != 'Savings';

  double sumTx(bool Function(Tx) f) {
    var s = 0.0;
    for (final t in txs) {
      if (f(t)) s += t.amt;
    }
    return s;
  }

  double sumIn(DateTime a, DateTime b, bool Function(Tx) f) => sumTx((t) => !t.date.isBefore(a) && t.date.isBefore(b) && f(t));
  double get cycSpent => sumTx((t) => isSpend(t) && inCycle(t));
  double get cycIncome => sumTx((t) => t.type == 'i' && inCycle(t));
  double spentCat(String c) => sumTx((t) => t.type == 'e' && t.cat == c && inCycle(t));
  double spentGrp(String g) => sumTx((t) => t.type == 'e' && catOf(t.cat).grp == g && inCycle(t));

  Map<String, double> daySpend() {
    final m = <String, double>{};
    for (final t in txs) {
      if (isSpend(t)) {
        final k = '${t.date.year}-${t.date.month}-${t.date.day}';
        m[k] = (m[k] ?? 0) + t.amt;
      }
    }
    return m;
  }

  bool get needSalary {
    if (salary <= 0) return false;
    final key = '${cStart.year}-${cStart.month}';
    if (snooze == key) return false;
    return !txs.any((t) => t.type == 'i' && t.cat == 'Salary' && inCycle(t));
  }

  Future<void> snoozeSalary() async {
    snooze = '${cStart.year}-${cStart.month}';
    await save();
  }

  // ---------- bills / emi helpers ----------
  String ym([DateTime? d]) {
    final x = d ?? now;
    return '${x.year}-${x.month}';
  }

  bool billPaid(Map b) => b['p'] == ym();
  DateTime dueOf(int day, bool paid) {
    final dd = day > 28 ? 28 : day;
    return DateTime(now.year, now.month + (paid ? 1 : 0), dd);
  }

  DateTime nextDay(int day) {
    final dd = day > 28 ? 28 : day;
    var d = DateTime(now.year, now.month, dd);
    if (d.isBefore(today)) d = DateTime(now.year, now.month + 1, dd);
    return d;
  }

  String whenText(DateTime d) {
    final x = d.difference(today).inDays;
    return x < 0 ? 'Overdue' : x == 0 ? 'Due today' : x == 1 ? 'Tomorrow' : 'In $x days';
  }

  bool loanDone(Map l) => (l['p'] as num) >= (l['t'] as num);
  bool loanPaidNow(Map l) => l['m'] == ym();
  double loanLeft(Map l) => (l['e'] as num).toDouble() * ((l['t'] as num).toInt() - (l['p'] as num).toInt());
  DateTime payoff(Map l) {
    final r = (l['t'] as num).toInt() - (l['p'] as num).toInt();
    final d = (l['d'] as num).toInt();
    final dd = d > 28 ? 28 : d;
    final first = DateTime(now.year, now.month + (loanPaidNow(l) ? 1 : 0), dd);
    return DateTime(first.year, first.month + (r > 1 ? r - 1 : 0), dd);
  }

  Future<void> payBill(Map<String, dynamic> b, Acc a) async {
    b['p'] = ym();
    await addTx(Tx(id: nid(), type: 'e', amt: (b['a'] as num).toDouble(), cat: 'Bills', note: '${b['n']}', acc: a.id, date: now));
  }

  Future<void> payLoan(Map<String, dynamic> l, Acc a) async {
    l['p'] = (l['p'] as num).toInt() + 1;
    l['m'] = ym();
    await addTx(Tx(id: nid(), type: 'e', amt: (l['e'] as num).toDouble(), cat: 'EMI', note: '${l['n']}', acc: a.id, date: now));
  }

  double get safePerDay {
    var unpaid = 0.0;
    for (final b in bills) {
      if (!billPaid(b) && dueOf((b['d'] as num).toInt(), false).isBefore(cEnd)) unpaid += (b['a'] as num).toDouble();
    }
    for (final l in loans) {
      if (!loanDone(l) && !loanPaidNow(l) && nextDay((l['d'] as num).toInt()).isBefore(cEnd)) unpaid += (l['e'] as num).toDouble();
    }
    final free = liquid - unpaid;
    return free > 0 ? free / daysLeft : 0.0;
  }

  List<DueItem> dues() {
    final out = <DueItem>[];
    for (final b in bills) {
      if (!billPaid(b)) out.add(DueItem('${b['n']}', (b['a'] as num).toDouble(), dueOf((b['d'] as num).toInt(), false), Icons.receipt_long_rounded, violet));
    }
    for (final l in loans) {
      if (!loanDone(l) && !loanPaidNow(l)) out.add(DueItem('${l['n']} EMI', (l['e'] as num).toDouble(), nextDay((l['d'] as num).toInt()), Icons.account_balance_rounded, red));
    }
    for (final a in accs) {
      if (a.kind == 'card') {
        final u = bal(a);
        if (u > 0) out.add(DueItem('${a.name} card bill', u, nextDay(a.due), Icons.credit_card_rounded, org));
      }
    }
    for (final u in udhaar) {
      final r = ((u['r'] ?? 0) as num).toInt();
      if (u['x'] != true && r > 0) {
        final gave = u['k'] == 'gave';
        out.add(DueItem(gave ? 'Collect from ${u['w']}' : 'Pay ${u['w']}', (u['a'] as num).toDouble(), DateTime.fromMillisecondsSinceEpoch(r), Icons.handshake_rounded, gave ? grn : red));
      }
    }
    out.sort((a, b) => a.date.compareTo(b.date));
    return out;
  }

  // ---------- udhaar / assets / net worth ----------
  double get toReceive {
    var s = 0.0;
    for (final u in udhaar) {
      if (u['x'] != true && u['k'] == 'gave') s += (u['a'] as num).toDouble();
    }
    return s;
  }

  double get toPay {
    var s = 0.0;
    for (final u in udhaar) {
      if (u['x'] != true && u['k'] != 'gave') s += (u['a'] as num).toDouble();
    }
    return s;
  }

  double get assetsTotal {
    var s = 0.0;
    for (final a in assets) {
      s += (a['v'] as num).toDouble();
    }
    return s;
  }

  double get loansLeft {
    var s = 0.0;
    for (final l in loans) {
      s += loanLeft(l);
    }
    return s;
  }

  double get netWorth => liquid + assetsTotal + toReceive - cardUsed - loansLeft - toPay;

  Future<void> settle(Map<String, dynamic> u, Acc? a) async {
    u['x'] = true;
    if (a != null) {
      final gave = u['k'] == 'gave';
      await addTx(Tx(id: nid(), type: gave ? 'i' : 'e', amt: (u['a'] as num).toDouble(), cat: 'Other', note: gave ? 'Returned by ${u['w']}' : 'Paid to ${u['w']}', acc: a.id, date: now));
    } else {
      await save();
    }
  }

  // ---------- goals ----------
  double goalMonthly(Map g) {
    final left = (g['t'] as num).toDouble() - (g['s'] as num).toDouble();
    final dl = ((g['dl'] ?? 0) as num).toInt();
    if (left <= 0 || dl <= 0) return 0;
    final days = DateTime.fromMillisecondsSinceEpoch(dl).difference(now).inDays;
    final months = days <= 30 ? 1 : (days / 30).ceil();
    return left / months;
  }

  Future<bool> fund(Map<String, dynamic> g, double v, Acc a) async {
    g['s'] = (g['s'] as num).toDouble() + v;
    final done = (g['s'] as num) >= (g['t'] as num);
    await addTx(Tx(id: nid(), type: 'e', amt: v, cat: 'Savings', note: '→ ${g['n']}', acc: a.id, date: now));
    return done;
  }

  // ---------- insights ----------
  List<Insight> insights() {
    final out = <Insight>[];
    if (txs.isEmpty) return out;
    final spent = cycSpent;
    final ds = daySpend();
    var we = 0.0, wk = 0.0;
    var weN = 0, wkN = 0;
    var d = cStart;
    while (!d.isAfter(today)) {
      final v = ds['${d.year}-${d.month}-${d.day}'] ?? 0;
      if (d.weekday >= 6) {
        we += v;
        weN++;
      } else {
        wk += v;
        wkN++;
      }
      d = DateTime(d.year, d.month, d.day + 1);
    }
    if (weN > 0 && wkN > 0 && we > 0 && wk > 0) {
      final a = we / weN, b = wk / wkN;
      if (a > b * 1.2) {
        out.add(Insight(Icons.weekend_rounded, org, 'You spend ${((a / b - 1) * 100).round()}% more on weekends than weekdays.'));
      } else if (b > a * 1.2) {
        out.add(Insight(Icons.work_history_rounded, blue, 'Weekdays cost you ${((b / a - 1) * 100).round()}% more per day than weekends.'));
      }
    }
    final base = salary > 0 ? salary : cycIncome;
    if (base > 0 && spent > 0) {
      final pace = spent / daysDone * totalDays;
      final left = base - pace;
      if (left >= 0) {
        out.add(Insight(Icons.trending_up_rounded, grn, 'At this pace you\'ll save about ${fmt(left)} this month.'));
      } else {
        out.add(Insight(Icons.warning_amber_rounded, red, 'At this pace you\'ll overspend by about ${fmt(-left)} this month.'));
      }
    }
    if (spent > 0) {
      String top = '';
      var tv = 0.0;
      for (final c in expCats) {
        final v = sumTx((t) => isSpend(t) && t.cat == c.name && inCycle(t));
        if (v > tv) {
          tv = v;
          top = c.name;
        }
      }
      if (top.isNotEmpty) out.add(Insight(catOf(top).icon, catOf(top).color, '$top is ${(tv / spent * 100).round()}% of your spending this month.'));
    }
    for (final e in budgets.entries) {
      final l = (e.value as num).toDouble();
      if (l > 0) {
        final r = spentCat(e.key) / l;
        if (r >= .8) {
          out.add(Insight(Icons.speed_rounded, r >= 1 ? red : org, '${e.key} budget is ${(r * 100).round()}% used.'));
          break;
        }
      }
    }
    final ps = cycStartK(1);
    final prev = sumIn(ps, DateTime(ps.year, ps.month, ps.day + daysDone), (t) => isSpend(t));
    if (prev > 0 && spent > 0) {
      final diff = ((spent / prev - 1) * 100).round();
      if (diff.abs() >= 10) {
        out.add(Insight(diff < 0 ? Icons.south_east_rounded : Icons.north_east_rounded, diff < 0 ? grn : org, 'Spending is ${diff.abs()}% ${diff < 0 ? 'lower' : 'higher'} than last month at this point.'));
      }
    }
    return out.take(4).toList();
  }

  // ---------- notifications scheduling ----------
  Future<void> reschedule() async {
    try {
      await Notif.cancelAll();
      if (!setupDone) return;
      DateTime at(DateTime d, int h, int m) => DateTime(d.year, d.month, d.day, h, m);
      if (on('daily')) {
        final n = notif['daily'] as Map;
        var t = DateTime(now.year, now.month, now.day, n['h'] as int, n['m'] as int);
        if (t.isBefore(now)) t = DateTime(t.year, t.month, t.day + 1, t.hour, t.minute);
        await Notif.at(1, t, 'Daily summary', 'Tap to see what you spent today and what is left to spend.', repeat: 'daily', payload: 'open');
      }
      if (on('salary')) {
        final n = notif['salary'] as Map;
        var t = DateTime(now.year, now.month, payday, n['h'] as int, n['m'] as int);
        if (t.isBefore(now)) t = DateTime(now.year, now.month + 1, payday, t.hour, t.minute);
        await Notif.at(2, t, 'Salary day 💰', 'Log your salary and plan the month with 50/30/20.', repeat: 'monthly', payload: 'open');
      }
      if (on('bill')) {
        final n = notif['bill'] as Map;
        final h = n['h'] as int, m = n['m'] as int;
        var i = 0;
        for (final it in dues()) {
          if (i >= 40) break;
          final base = 1000 + i * 2;
          await Notif.at(base, at(it.date.subtract(const Duration(days: 1)), h, m), '${it.title} due tomorrow', '${fmt(it.amt)} is due tomorrow.', payload: 'money');
          await Notif.at(base + 1, at(it.date, h, m), '${it.title} due today', '${fmt(it.amt)} is due today.', payload: 'money', add: false);
          i++;
        }
      }
    } catch (_) {}
  }
}
