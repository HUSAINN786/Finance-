import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'add_sheet.dart';
import 'core.dart';
import 'ui.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryS();
}

class _HistoryS extends State<HistoryPage> {
  String q = '', f = 'all', tag = '';

  String dayLabel(DateTime d) {
    final t = store.today;
    final x = DateTime(d.year, d.month, d.day);
    final diff = t.difference(x).inDays;
    if (diff == 0) return 'Today';
    if (diff == 1) return 'Yesterday';
    return '${d.day} ${mon[d.month - 1]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) => Live((context) {
        final p = Pal.of(context);
        final s = store;
        if (s.txs.isEmpty) {
          return EmptyState(Icons.receipt_long_rounded, 'No transactions yet', 'Tap the + button to add your first expense or income.', label: 'Add transaction', onTap: () => openAdd(context));
        }
        final allTags = <String>{};
        for (final t in s.txs) {
          allTags.addAll(t.tags);
        }
        final ql = q.toLowerCase();
        final list = s.txs.where((t) {
          if (f != 'all' && t.type != f) return false;
          if (tag.isNotEmpty && !t.tags.contains(tag)) return false;
          if (ql.isEmpty) return true;
          return t.cat.toLowerCase().contains(ql) || t.note.toLowerCase().contains(ql) || t.tags.any((x) => x.toLowerCase().contains(ql)) || trimNum(t.amt).contains(ql);
        }).toList();
        final rows = <Object>[];
        String last = '';
        for (final t in list) {
          final l = dayLabel(t.date);
          if (l != last) {
            rows.add(l);
            last = l;
          }
          rows.add(t);
        }
        return ListView.builder(
            physics: bounce,
            padding: pagePad,
            itemCount: rows.length + 2,
            itemBuilder: (c, i) {
              if (i == 0) {
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const PageTitle('History'),
                  TextField(
                      onChanged: (v) => setState(() => q = v),
                      decoration: InputDecoration(hintText: 'Search category, note, tag, amount', prefixIcon: Icon(Icons.search_rounded, color: p.sub), filled: true, fillColor: p.card, contentPadding: const EdgeInsets.symmetric(vertical: 14), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.line)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.line)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.accent, width: 2)))),
                  const SizedBox(height: 12),
                  SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(children: [
                        for (final e in const [['all', 'All'], ['e', 'Expense'], ['i', 'Income'], ['t', 'Transfers']]) Padding(padding: const EdgeInsets.only(right: 8), child: Pill(e[1], f == e[0], () => setState(() => f = e[0]))),
                        for (final t in allTags) Padding(padding: const EdgeInsets.only(right: 8), child: Pill('#$t', tag == t, () => setState(() => tag = tag == t ? '' : t), color: blue)),
                      ])),
                  const SizedBox(height: 14),
                  if (list.isEmpty) Padding(padding: const EdgeInsets.all(30), child: Center(child: Text('Nothing matches your search', style: TextStyle(color: p.sub)))),
                ]);
              }
              if (i == rows.length + 1) return Padding(padding: const EdgeInsets.only(top: 8), child: Center(child: Text('Swipe right to edit · left to delete', style: TextStyle(color: p.sub, fontSize: 12))));
              final r = rows[i - 1];
              if (r is String) return Padding(padding: const EdgeInsets.only(top: 6, bottom: 8), child: Text(r, style: TextStyle(color: p.sub, fontWeight: FontWeight.w700)));
              final t = r as Tx;
              return Pop(
                  i - 1,
                  Dismissible(
                      key: ValueKey(t.id),
                      background: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.only(left: 22), alignment: Alignment.centerLeft, decoration: BoxDecoration(color: blue.withOpacity(.85), borderRadius: BorderRadius.circular(22)), child: const Icon(Icons.edit_rounded, color: Colors.white)),
                      secondaryBackground: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.only(right: 22), alignment: Alignment.centerRight, decoration: BoxDecoration(color: red.withOpacity(.9), borderRadius: BorderRadius.circular(22)), child: const Icon(Icons.delete_rounded, color: Colors.white)),
                      confirmDismiss: (dir) async {
                        if (dir == DismissDirection.startToEnd) {
                          HapticFeedback.selectionClick();
                          openAdd(context, edit: t);
                          return false;
                        }
                        return true;
                      },
                      onDismissed: (_) {
                        HapticFeedback.mediumImpact();
                        store.deleteTx(t);
                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: const Text('Transaction deleted'), behavior: SnackBarBehavior.floating, action: SnackBarAction(label: 'UNDO', textColor: goldL, onPressed: () => store.restoreTx(t))));
                      },
                      child: TxTile(t, onTap: () => openAdd(context, edit: t))));
            });
      });
}
