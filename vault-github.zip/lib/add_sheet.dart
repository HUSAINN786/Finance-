import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'ui.dart';

void openAdd(BuildContext context, {Tx? edit, String type = 'e', String? from, String? to, double? amount}) {
  final p = Pal.of(context);
  showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: p.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (c) => AddSheet(host: context, edit: edit, type: type, from: from, to: to, amount: amount));
}

class AddSheet extends StatefulWidget {
  final BuildContext host;
  final Tx? edit;
  final String type;
  final String? from, to;
  final double? amount;
  const AddSheet({super.key, required this.host, this.edit, this.type = 'e', this.from, this.to, this.amount});
  @override
  State<AddSheet> createState() => _AddS();
}

class _AddS extends State<AddSheet> {
  late String type, cat, acc, to;
  String amt = '', note = '';
  String? err;
  List<String> tags = [];
  late DateTime date;

  @override
  void initState() {
    super.initState();
    final e = widget.edit;
    final accs = store.accs;
    final first = accs.firstWhere((a) => a.kind != 'card', orElse: () => accs.first).id;
    if (e != null) {
      type = e.type;
      cat = e.cat;
      acc = e.acc;
      to = e.to.isEmpty ? first : e.to;
      amt = trimNum(e.amt);
      date = e.date;
      note = e.note;
      tags = List<String>.from(e.tags);
    } else {
      type = widget.type;
      cat = type == 'i' ? 'Salary' : 'Food';
      acc = widget.from ?? first;
      to = widget.to ?? accs.firstWhere((a) => a.id != acc, orElse: () => accs.first).id;
      date = DateTime.now();
      amt = widget.amount != null ? trimNum(widget.amount!) : '';
    }
  }

  void key(String k) {
    HapticFeedback.selectionClick();
    setState(() {
      err = null;
      if (k == '<') {
        if (amt.isNotEmpty) amt = amt.substring(0, amt.length - 1);
      } else if (k == '.') {
        if (!amt.contains('.')) amt = amt.isEmpty ? '0.' : '$amt.';
      } else {
        if (amt.contains('.') && amt.split('.')[1].length >= 2) return;
        if (amt.replaceAll('.', '').length >= 9) return;
        if (amt == '0') amt = '';
        amt += k;
      }
    });
  }

  String get shown {
    if (amt.isEmpty) return '0';
    final parts = amt.split('.');
    return groupIN(parts[0]) + (amt.contains('.') ? '.${parts.length > 1 ? parts[1] : ''}' : '');
  }

  String dateLabel() {
    final n = DateTime.now();
    final d0 = DateTime(date.year, date.month, date.day);
    final t0 = DateTime(n.year, n.month, n.day);
    final diff = t0.difference(d0).inDays;
    if (diff == 0) return 'Today';
    if (diff == 1) return 'Yesterday';
    return '${date.day} ${mon[date.month - 1]}';
  }

  Future<void> pickDate() async {
    final d = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime.now().add(const Duration(days: 365)));
    if (d != null) {
      final n = DateTime.now();
      setState(() => date = DateTime(d.year, d.month, d.day, n.hour, n.minute));
    }
  }

  Future<void> pickNote() async {
    final r = await formDialog(context, 'Note', [F('What was it for?', init: note)], ok: 'Done');
    if (r != null) setState(() => note = r[0]);
  }

  Future<void> pickTags() async {
    final r = await formDialog(context, 'Tags', [F('Comma separated, e.g. trip, office', init: tags.join(', '))], ok: 'Done');
    if (r != null) {
      setState(() => tags = r[0].split(',').map((e) => e.replaceAll('#', '').trim()).where((e) => e.isNotEmpty).toList());
    }
  }

  Future<void> save() async {
    final v = double.tryParse(amt);
    if (v == null || v <= 0) {
      HapticFeedback.heavyImpact();
      setState(() => err = 'Enter an amount');
      return;
    }
    if (type == 't' && acc == to) {
      HapticFeedback.heavyImpact();
      setState(() => err = 'Pick two different accounts');
      return;
    }
    String c = cat;
    if (type == 't') {
      c = (store.accById(to)?.kind == 'cash' && store.accById(acc)?.kind == 'bank') ? 'ATM' : 'Transfer';
    }
    final e = widget.edit;
    final tx = Tx(id: e?.id ?? store.nid(), type: type, amt: v, cat: c, note: note, acc: acc, to: type == 't' ? to : '', date: date, tags: tags);
    final host = widget.host;
    Navigator.pop(context);
    HapticFeedback.mediumImpact();
    if (e != null) {
      await store.updateTx(e, tx);
    } else {
      await store.addTx(tx);
      if (host.mounted) coinDrop(host);
    }
  }

  Widget typeBtn(Pal p, String t, String label, IconData ic, Color col) {
    final s = type == t;
    return Expanded(
        child: GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() {
                type = t;
                err = null;
                if (t == 'i' && !incCats.any((c) => c.name == cat)) cat = 'Salary';
                if (t == 'e' && !expCats.any((c) => c.name == cat)) cat = 'Food';
              });
            },
            child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                padding: const EdgeInsets.symmetric(vertical: 11),
                decoration: BoxDecoration(color: s ? col : p.chip, borderRadius: BorderRadius.circular(16)),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(ic, size: 17, color: s ? Colors.white : p.sub),
                  const SizedBox(width: 6),
                  Flexible(child: Text(label, maxLines: 1, softWrap: false, overflow: TextOverflow.fade, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: s ? Colors.white : p.text))),
                ]))));
  }

  Widget catTile(Pal p, Cat c) {
    final s = cat == c.name;
    return GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => cat = c.name);
        },
        child: SizedBox(
            width: 66,
            child: Column(children: [
              AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: s ? 54 : 48,
                  height: s ? 54 : 48,
                  decoration: BoxDecoration(color: s ? c.color : c.color.withOpacity(.13), borderRadius: BorderRadius.circular(18), border: Border.all(color: s ? p.text.withOpacity(.12) : Colors.transparent, width: 2)),
                  child: Icon(c.icon, color: s ? Colors.white : c.color, size: s ? 27 : 24)),
              const SizedBox(height: 5),
              Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, fontWeight: s ? FontWeight.w800 : FontWeight.w500, color: s ? p.text : p.sub)),
            ])));
  }

  Widget accRow(Pal p, String label, String sel, void Function(String) onSel) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(color: p.sub, fontSize: 12.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [for (final a in store.accs) Padding(padding: const EdgeInsets.only(right: 8), child: Pill(a.name, sel == a.id, () => setState(() => onSel(a.id)), icon: accIcon(a.kind)))])),
        const SizedBox(height: 12),
      ]);

  Widget chip(Pal p, IconData ic, String label, VoidCallback onTap, {bool on = false}) => GestureDetector(
      onTap: onTap,
      child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(color: on ? p.accent.withOpacity(.16) : p.chip, borderRadius: BorderRadius.circular(14)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(ic, size: 16, color: on ? p.accent : p.sub),
            const SizedBox(width: 6),
            ConstrainedBox(constraints: const BoxConstraints(maxWidth: 110), child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: on ? p.accent : p.text))),
          ])));

  Widget keyBtn(Pal p, String k) => Material(
      color: p.chip,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => key(k),
          onLongPress: k == '<' ? () => setState(() => amt = '') : null,
          child: Center(child: k == '<' ? Icon(Icons.backspace_outlined, color: p.text) : Text(k, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)))));

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final col = type == 'i' ? grn : type == 't' ? blue : p.accent;
    final cats = type == 'i' ? incCats : expCats;
    return SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(20, 10, 20, 14 + MediaQuery.of(context).padding.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: p.line, borderRadius: BorderRadius.circular(4))),
          const SizedBox(height: 14),
          Row(children: [
            typeBtn(p, 'e', 'Expense', Icons.north_east_rounded, red),
            typeBtn(p, 'i', 'Income', Icons.south_west_rounded, grn),
            typeBtn(p, 't', 'Transfer', Icons.swap_horiz_rounded, blue),
          ]),
          const SizedBox(height: 14),
          FittedBox(fit: BoxFit.scaleDown, child: Text('$cur$shown', style: TextStyle(fontSize: 48, fontWeight: FontWeight.w800, color: amt.isEmpty ? p.sub.withOpacity(.5) : col))),
          SizedBox(height: 20, child: err == null ? null : Text(err!, style: const TextStyle(color: red, fontWeight: FontWeight.w600))),
          if (type != 't') ...[
            SizedBox(height: 82, child: ListView(scrollDirection: Axis.horizontal, children: [for (final c in cats) catTile(p, c)])),
            const SizedBox(height: 8),
            accRow(p, type == 'i' ? 'Received in' : 'Paid from', acc, (id) => acc = id),
          ] else ...[
            accRow(p, 'From', acc, (id) => acc = id),
            accRow(p, 'To', to, (id) => to = id),
          ],
          Row(children: [
            chip(p, Icons.event_rounded, dateLabel(), pickDate, on: true),
            const SizedBox(width: 8),
            chip(p, Icons.edit_note_rounded, note.isEmpty ? 'Add note' : note, pickNote, on: note.isNotEmpty),
            const SizedBox(width: 8),
            chip(p, Icons.sell_rounded, tags.isEmpty ? 'Tags' : tags.map((e) => '#$e').join(' '), pickTags, on: tags.isNotEmpty),
          ]),
          const SizedBox(height: 14),
          GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 2.4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              children: [for (final k in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', '<']) keyBtn(p, k)]),
          const SizedBox(height: 14),
          SizedBox(
              width: double.infinity,
              child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: col, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 17), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                  onPressed: save,
                  child: Text(widget.edit != null ? 'Update' : 'Save', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)))),
        ]));
  }
}
