import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;

/// Thin, fail-safe wrapper around flutter_local_notifications.
/// Every call is wrapped in try/catch so a notification problem can never crash the app.
class Notif {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ok = false;

  /// Set when the user taps a notification: 'add', 'money' or 'open'.
  static final ValueNotifier<String?> tap = ValueNotifier<String?>(null);

  static Future<void> init() async {
    try {
      tzd.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
      await _p.initialize(
        const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
        onDidReceiveNotificationResponse: (NotificationResponse r) {
          tap.value = r.actionId == 'add' ? 'add' : (r.payload ?? 'open');
        },
      );
      _ok = true;
    } catch (_) {}
  }

  static NotificationDetails _det(String id, String name, bool add) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        id,
        name,
        channelDescription: name,
        importance: Importance.high,
        priority: Priority.high,
        actions: add ? const [AndroidNotificationAction('add', 'Add expense', showsUserInterface: true)] : null,
      ),
    );
  }

  static Future<bool> askPermission() async {
    try {
      final a = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final r = await a?.requestNotificationsPermission();
      return r ?? true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> show(int id, String title, String body, {String payload = 'open'}) async {
    if (!_ok) return;
    try {
      await _p.show(id, title, body, _det('alerts', 'Alerts', true), payload: payload);
    } catch (_) {}
  }

  /// repeat: null (one-shot), 'daily' or 'monthly'.
  static Future<void> at(int id, DateTime when, String title, String body, {String payload = 'open', String? repeat, bool add = true}) async {
    if (!_ok) return;
    try {
      final t = tz.TZDateTime.from(when, tz.local);
      if (repeat == null && t.isBefore(tz.TZDateTime.now(tz.local))) return;
      await _p.zonedSchedule(
        id,
        title,
        body,
        t,
        _det('reminders', 'Reminders', add),
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        payload: payload,
        matchDateTimeComponents: repeat == 'daily'
            ? DateTimeComponents.time
            : repeat == 'monthly'
                ? DateTimeComponents.dayOfMonthAndTime
                : null,
      );
    } catch (_) {}
  }

  static Future<void> cancelAll() async {
    if (!_ok) return;
    try {
      await _p.cancelAll();
    } catch (_) {}
  }
}
