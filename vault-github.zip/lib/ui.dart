import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';

const bounce = BouncingScrollPhysics();
const pagePad = EdgeInsets.fromLTRB(20, 12, 20, 110);
const heroGrad = LinearGradient(colors: [Color(0xFF1B2440), Color(0xFF2E3560), Color(0xFFC8962B)], stops: [0, .55, 1], begin: Alignment.topLeft, end: Alignment.bottomRight);

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
}

class Live extends StatelessWidget {
  final Widget Function(BuildContext) b;
  const Live(this.b, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: store, builder: (c, _) => b(c));
}

class Logo extends StatelessWidget {
  final double s;
  const Logo(this.s, {super.key});
  @override
  Widget build(BuildContext context) => Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(s * .26),
          gradient: const LinearGradient(colors: [Color(0xFFF5D76E), Color(0xFFB8860B)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: const Color(0xFFC8962B).withOpacity(.4), blurRadius: s / 3)]),
      child: Center(child: Text('V', style: TextStyle(fontSize: s * .6, fontWeight: FontWeight.w800, color: navy))));
}

class Pop extends StatelessWidget {
  final int i;
  final Widget child;
  const Pop(this.i, this.child, {super.key});
  @override
  Widget build(BuildContext context) {
    final k = i > 10 ? 10 : i;
    return TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: 1),
        duration: Duration(milliseconds: 380 + k * 70),
        curve: Curves.easeOutCubic,
        builder: (_, v, ch) => Opacity(opacity: c01(v), child: Transform.translate(offset: Offset(0, 26 * (1 - v)), child: ch)),
        child: child);
  }
}

class AppCard extends StatelessWidget {
  final Widget child;
  final Gradient? gradient;
  final EdgeInsets padding, margin;
  final VoidCallback? onTap;
  const AppCard({super.key, required this.child, this.gradient, this.padding = const EdgeInsets.all(18), this.margin = const EdgeInsets.only(bottom: 14), this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
        width: double.infinity,
        margin: margin,
        decoration: BoxDecoration(
            color: gradient == null ? p.card : null,
            gradient: gradient,
            borderRadius: BorderRadius.circular(22),
            border: (p.isDark && gradient == null) ? Border.all(color: p.line) : null,
            boxShadow: gradient == null ? p.shadow : const [BoxShadow(color: Color(0x401B2440), blurRadius: 26, offset: Offset(0, 12))]),
        child: Material(
            color: Colors.transparent,
            child: InkWell(borderRadius: BorderRadius.circular(22), onTap: onTap, child: Padding(padding: padding, child: child))));
  }
}

class _Slide extends GradientTransform {
  final double p;
  const _Slide(this.p);
  @override
  Matrix4? transform(Rect bounds, {TextDirection? textDirection}) => Matrix4.translationValues(bounds.width * p, 0, 0);
}

/// Gold shimmer sweeping across its (text) child.
class Shine extends StatefulWidget {
  final Widget child;
  const Shine({super.key, required this.child});
  @override
  State<Shine> createState() => _ShineS();
}

class _ShineS extends State<Shine> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2800))..repeat();
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
      animation: c,
      builder: (_, ch) => ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (r) => LinearGradient(colors: const [goldL, Colors.white, goldL], stops: const [0.35, 0.5, 0.65], transform: _Slide(c.value * 2.4 - 1.2)).createShader(r),
          child: ch),
      child: widget.child);
}

class Count extends StatelessWidget {
  final double v;
  final TextStyle? style;
  final bool money;
  final String suffix;
  const Count(this.v, {super.key, this.style, this.money = true, this.suffix = ''});
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: v.isNaN ? 0.0 : v),
      duration: const Duration(milliseconds: 1000),
      curve: Curves.easeOutCubic,
      builder: (_, x, __) => Text((money ? fmt(x) : x.round().toString()) + suffix, style: style));
}

class RingPainter extends CustomPainter {
  final double v, w;
  final Color c, track;
  RingPainter(this.v, this.c, this.track, this.w);
  @override
  void paint(Canvas cv, Size s) {
    final r = Rect.fromLTWH(w / 2 + 1, w / 2 + 1, s.width - w - 2, s.height - w - 2);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round;
    cv.drawArc(r, 0, 6.2832, false, p..color = track);
    if (v > 0.001) cv.drawArc(r, -1.5708, 6.2832 * v, false, p..color = c);
  }

  @override
  bool shouldRepaint(RingPainter o) => o.v != v || o.c != c || o.track != track;
}

class RingW extends StatelessWidget {
  final double v, size, w;
  final Color color;
  final Widget child;
  const RingW(this.v, this.color, this.size, this.child, {super.key, this.w = 9});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: c01(v)),
        duration: const Duration(milliseconds: 1100),
        curve: Curves.easeOutCubic,
        builder: (_, x, __) => SizedBox(width: size, height: size, child: CustomPaint(painter: RingPainter(x, color, p.line, w), child: Center(child: child))));
  }
}

class Bar extends StatelessWidget {
  final double v, h;
  final Color color;
  const Bar(this.v, this.color, {super.key, this.h = 8});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: c01(v)),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
        builder: (_, x, __) => ClipRRect(borderRadius: BorderRadius.circular(h), child: LinearProgressIndicator(value: x, minHeight: h, color: color, backgroundColor: p.line)));
  }
}

class DonutPainter extends CustomPainter {
  final List<double> vals;
  final List<Color> cols;
  final double t;
  final Color track;
  DonutPainter(this.vals, this.cols, this.t, this.track);
  @override
  void paint(Canvas cv, Size s) {
    const w = 24.0;
    final r = Rect.fromLTWH(w / 2, w / 2, s.width - w, s.height - w);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w;
    final total = vals.fold<double>(0, (a, b) => a + b);
    if (total <= 0) {
      cv.drawArc(r, 0, 6.2832, false, p..color = track);
      return;
    }
    var start = -math.pi / 2;
    for (var i = 0; i < vals.length; i++) {
      final sw = vals[i] / total * 2 * math.pi * t;
      final gap = sw > 0.08 ? 0.04 : 0.0;
      cv.drawArc(r, start, math.max(0.0, sw - gap), false, p..color = cols[i]);
      start += sw;
    }
  }

  @override
  bool shouldRepaint(DonutPainter o) => o.t != t || o.vals != vals;
}

class TrendPainter extends CustomPainter {
  final List<double> inc, exp;
  final List<String> labels;
  final double t;
  final Color incC, expC, text, grid;
  TrendPainter(this.inc, this.exp, this.labels, this.t, this.incC, this.expC, this.text, this.grid);
  void _txt(Canvas cv, String s, double x, double y, double fs) {
    final tp = TextPainter(text: TextSpan(text: s, style: TextStyle(color: text, fontSize: fs)), textDirection: TextDirection.ltr)..layout();
    tp.paint(cv, Offset(x - tp.width / 2, y));
  }

  @override
  void paint(Canvas cv, Size s) {
    final n = labels.length;
    if (n == 0) return;
    final h0 = s.height - 22;
    var mx = 1.0;
    for (var i = 0; i < n; i++) {
      mx = math.max(mx, math.max(inc[i], exp[i]));
    }
    final gp = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (var k = 0; k <= 3; k++) {
      final y = h0 - h0 * k / 3 * .92;
      cv.drawLine(Offset(0, y), Offset(s.width, y), gp);
    }
    final slot = s.width / n;
    final bw = slot * .26;
    for (var i = 0; i < n; i++) {
      final cx = slot * i + slot / 2;
      final hi = inc[i] / mx * h0 * .92 * t;
      final he = exp[i] / mx * h0 * .92 * t;
      const rd = Radius.circular(6);
      cv.drawRRect(RRect.fromRectAndCorners(Rect.fromLTWH(cx - bw - 2, h0 - hi, bw, hi), topLeft: rd, topRight: rd), Paint()..color = incC);
      cv.drawRRect(RRect.fromRectAndCorners(Rect.fromLTWH(cx + 2, h0 - he, bw, he), topLeft: rd, topRight: rd), Paint()..color = expC);
      _txt(cv, labels[i], cx, h0 + 6, 11);
    }
  }

  @override
  bool shouldRepaint(TrendPainter o) => o.t != t || o.inc != inc || o.exp != exp;
}

class Pill extends StatelessWidget {
  final String label;
  final bool sel;
  final VoidCallback onTap;
  final IconData? icon;
  final Color? color;
  const Pill(this.label, this.sel, this.onTap, {super.key, this.icon, this.color});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final fg = sel ? p.onAccent : p.text;
    return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          HapticFeedback.selectionClick();
          onTap();
        },
        child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(color: sel ? (color ?? p.accent) : p.chip, borderRadius: BorderRadius.circular(30)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              if (icon != null) ...[Icon(icon, size: 16, color: sel ? fg : p.sub), const SizedBox(width: 6)],
              Text(label, maxLines: 1, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: fg)),
            ])));
  }
}

class Sec extends StatelessWidget {
  final String t;
  final Widget? trail;
  const Sec(this.t, {super.key, this.trail});
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 10),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(t, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)), if (trail != null) trail!]));
}

class PageTitle extends StatelessWidget {
  final String t;
  final String? sub;
  const PageTitle(this.t, {super.key, this.sub});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          if (sub != null) Text(sub!, style: TextStyle(color: p.sub)),
        ]));
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  final String? label;
  final VoidCallback? onTap;
  const EmptyState(this.icon, this.title, this.sub, {super.key, this.label, this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Center(
        child: Padding(
            padding: const EdgeInsets.all(28),
            child: TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: 1),
                duration: const Duration(milliseconds: 900),
                curve: Curves.elasticOut,
                builder: (_, v, ch) => Transform.scale(scale: v.clamp(0.0, 1.2).toDouble(), child: ch),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withOpacity(.14)),
                      child: Icon(icon, size: 40, color: p.accent)),
                  const SizedBox(height: 18),
                  Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(sub, textAlign: TextAlign.center, style: TextStyle(color: p.sub, height: 1.4)),
                  if (onTap != null) ...[
                    const SizedBox(height: 18),
                    FilledButton(style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14)), onPressed: onTap, child: Text(label ?? 'Get started')),
                  ],
                ]))));
  }
}

class TxTile extends StatelessWidget {
  final Tx t;
  final VoidCallback? onTap;
  const TxTile(this.t, {super.key, this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final c = catOf(t.cat);
    final inc = t.type == 'i', tr = t.type == 't';
    final col = inc ? grn : c.color;
    final from = store.accById(t.acc)?.name ?? '';
    final to = store.accById(t.to)?.name ?? '';
    final title = tr ? (t.cat == 'ATM' ? 'ATM withdrawal' : 'Transfer') : t.cat;
    var sub = '${t.date.day} ${mon[t.date.month - 1]} · ${tr ? '$from → $to' : from}';
    if (t.note.isNotEmpty) sub += ' · ${t.note}';
    return AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        margin: const EdgeInsets.only(bottom: 10),
        onTap: onTap,
        child: Row(children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(color: col.withOpacity(.14), borderRadius: BorderRadius.circular(14)), child: Icon(inc ? Icons.south_west_rounded : c.icon, color: col, size: 22)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.sub, fontSize: 12.5)),
            if (t.tags.isNotEmpty) Text(t.tags.map((x) => '#$x').join('  '), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.accent, fontSize: 12, fontWeight: FontWeight.w600)),
          ])),
          const SizedBox(width: 8),
          Text('${inc ? '+' : tr ? '' : '-'}${fmt(t.amt)}', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5, color: inc ? grn : tr ? p.sub : p.text)),
        ]));
  }
}

// ---------- dialogs ----------
class F {
  final String label, init;
  final bool num;
  final List<String>? choices;
  const F(this.label, {this.num = false, this.choices, this.init = ''});
}

Future<List<String>?> formDialog(BuildContext context, String title, List<F> fields, {String ok = 'Save'}) {
  final p = Pal.of(context);
  final ctrls = fields.map((f) => TextEditingController(text: (f.init.isEmpty && f.choices != null) ? f.choices!.first : f.init)).toList();
  return showDialog<List<String>>(
      context: context,
      builder: (d) => StatefulBuilder(
          builder: (d, ss) => AlertDialog(
                backgroundColor: p.card,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
                title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (var i = 0; i < fields.length; i++)
                    Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: fields[i].choices != null
                            ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(fields[i].label, style: TextStyle(color: p.sub, fontSize: 12.5)),
                                const SizedBox(height: 6),
                                Wrap(spacing: 8, runSpacing: 8, children: [
                                  for (final ch in fields[i].choices!) Pill(ch, ctrls[i].text == ch, () => ss(() => ctrls[i].text = ch)),
                                ]),
                              ])
                            : TextField(
                                controller: ctrls[i],
                                keyboardType: fields[i].num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
                                textCapitalization: fields[i].num ? TextCapitalization.none : TextCapitalization.sentences,
                                decoration: InputDecoration(labelText: fields[i].label, filled: true, fillColor: p.chip, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)))),
                ])),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(d), child: Text('Cancel', style: TextStyle(color: p.sub))),
                  FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
                      onPressed: () => Navigator.pop(d, ctrls.map((c) => c.text.trim()).toList()),
                      child: Text(ok)),
                ],
              )));
}

Future<bool> confirmDialog(BuildContext context, String title, String body, {String ok = 'Delete'}) async {
  final p = Pal.of(context);
  final r = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
            backgroundColor: p.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            content: Text(body),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d, false), child: Text('Cancel', style: TextStyle(color: p.sub))),
              FilledButton(style: FilledButton.styleFrom(backgroundColor: red, foregroundColor: Colors.white), onPressed: () => Navigator.pop(d, true), child: Text(ok)),
            ],
          ));
  return r == true;
}

Future<Acc?> pickAcc(BuildContext context, {bool noCard = false, String title = 'Pay from'}) async {
  final list = store.accs.where((a) => !(noCard && a.kind == 'card')).toList();
  if (list.isEmpty) return null;
  if (list.length == 1) return list.first;
  final p = Pal.of(context);
  return showDialog<Acc>(
      context: context,
      builder: (d) => SimpleDialog(
            backgroundColor: p.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            children: list
                .map((a) => SimpleDialogOption(
                    onPressed: () => Navigator.pop(d, a),
                    child: Row(children: [Icon(accIcon(a.kind), color: p.accent), const SizedBox(width: 12), Expanded(child: Text(a.name)), Text(fmt(store.bal(a)), style: TextStyle(color: p.sub))])))
                .toList(),
          ));
}

// ---------- celebrations ----------
void _overlay(BuildContext context, Widget w, int ms) {
  final o = Overlay.of(context);
  late OverlayEntry e;
  e = OverlayEntry(builder: (_) => IgnorePointer(child: w));
  o.insert(e);
  Future.delayed(Duration(milliseconds: ms), () {
    try {
      e.remove();
    } catch (_) {}
  });
}

void coinDrop(BuildContext context) => _overlay(context, const _Coin(), 1500);
void confetti(BuildContext context) => _overlay(context, const _Confetti(), 2800);

class _Coin extends StatefulWidget {
  const _Coin();
  @override
  State<_Coin> createState() => _CoinS();
}

class _CoinS extends State<_Coin> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..forward();
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sz = MediaQuery.of(context).size;
    return AnimatedBuilder(
        animation: c,
        builder: (_, __) {
          final y = Curves.bounceOut.transform(c.value);
          final fade = c.value > .75 ? (1 - (c.value - .75) / .25) : 1.0;
          return Stack(children: [
            Positioned(
                left: sz.width / 2 - 30,
                top: -70 + (sz.height * .62) * y,
                child: Opacity(
                    opacity: c01(fade),
                    child: Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()..rotateY(c.value * 12),
                        child: Container(
                            width: 60,
                            height: 60,
                            decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFF5D76E), Color(0xFFB8860B)], begin: Alignment.topLeft, end: Alignment.bottomRight), boxShadow: [BoxShadow(color: Color(0x66C8962B), blurRadius: 18)]),
                            child: const Center(child: Text('₹', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: navy, decoration: TextDecoration.none))))))),
          ]);
        });
  }
}

class _Confetti extends StatefulWidget {
  const _Confetti();
  @override
  State<_Confetti> createState() => _ConfettiS();
}

class _Part {
  final double x, vx, vy, rot, size;
  final Color c;
  _Part(this.x, this.vx, this.vy, this.rot, this.size, this.c);
}

class _ConfettiS extends State<_Confetti> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..forward();
  final List<_Part> ps = [];
  @override
  void initState() {
    super.initState();
    final r = math.Random();
    const cols = [goldL, grn, blue, red, violet, org];
    for (var i = 0; i < 70; i++) {
      ps.add(_Part(r.nextDouble(), (r.nextDouble() - .5) * .5, .15 + r.nextDouble() * .5, r.nextDouble() * 6, 6 + r.nextDouble() * 7, cols[r.nextInt(cols.length)]));
    }
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: c, builder: (_, __) => CustomPaint(size: Size.infinite, painter: _ConfP(ps, c.value)));
}

class _ConfP extends CustomPainter {
  final List<_Part> ps;
  final double t;
  _ConfP(this.ps, this.t);
  @override
  void paint(Canvas cv, Size s) {
    for (final p in ps) {
      final x = p.x * s.width + p.vx * t * s.width;
      final y = -20 + (p.vy * t + 1.1 * t * t) * s.height;
      cv.save();
      cv.translate(x, y);
      cv.rotate(p.rot + t * 8);
      cv.drawRect(Rect.fromLTWH(0, 0, p.size, p.size * .55), Paint()..color = p.c.withOpacity(c01(1.4 - t)));
      cv.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfP o) => true;
}
