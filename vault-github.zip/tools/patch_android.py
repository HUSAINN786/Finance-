#!/usr/bin/env python3
"""Patches the Flutter-generated android/ project for Vault:
 - core library desugaring + notification permissions/receivers (flutter_local_notifications)
 - app label
Run after `flutter create` and before `flutter build apk`."""
import os, re, sys

root = os.path.join(os.getcwd(), 'android', 'app')

# ---- Gradle: desugaring ----
groovy = os.path.join(root, 'build.gradle')
kts = os.path.join(root, 'build.gradle.kts')
if os.path.exists(groovy):
    s = open(groovy).read()
    if 'coreLibraryDesugaringEnabled' not in s:
        s = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', s, count=1)
        s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'\n}\n"
        open(groovy, 'w').write(s)
elif os.path.exists(kts):
    s = open(kts).read()
    if 'isCoreLibraryDesugaringEnabled' not in s:
        s = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true', s, count=1)
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")\n}\n'
        open(kts, 'w').write(s)
else:
    sys.exit('No app build.gradle found')

# ---- Manifest ----
mf = os.path.join(root, 'src', 'main', 'AndroidManifest.xml')
m = open(mf).read()
if 'POST_NOTIFICATIONS' not in m:
    perms = ('    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
             '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>\n'
             '    <uses-permission android:name="android.permission.VIBRATE"/>\n')
    m = m.replace('<application', perms + '    <application', 1)
    recv = ('        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />\n'
            '        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">\n'
            '            <intent-filter>\n'
            '                <action android:name="android.intent.action.BOOT_COMPLETED"/>\n'
            '                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>\n'
            '                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>\n'
            '                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>\n'
            '            </intent-filter>\n'
            '        </receiver>\n')
    m = m.replace('</application>', recv + '    </application>', 1)
m = re.sub(r'android:label="[^"]*"', 'android:label="Vault"', m, count=1)
open(mf, 'w').write(m)
print('Android project patched')
